import React from 'react';
import BreadCrumb from '../../../Components/Common/BreadCrumb';
import { Container } from 'reactstrap';

import List from './List';
import MyBreadCrumb from "../../../Components/Common/MyBreadCrumb";

const CollectionList = () => {
    document.title = "Collection List | DRManager";

    const breadcrumbItems = [
        { label: 'Databases', path: '/databases' },
        { label: 'Collections', path: '/collections', active: true }
    ];

    return (
        <React.Fragment>
            <div className="page-content">
                <Container fluid>
                    {/*<BreadCrumb title="Collections" pageTitle="Collections" />*/}
                    <MyBreadCrumb items={breadcrumbItems} />
                    <List />
                </Container>
            </div>
        </React.Fragment>
    );
};

export default CollectionList;