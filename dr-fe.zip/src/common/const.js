export const OptionKeeping = 0
export const OptionSyncForward = 1
export const OptionSyncBackward = 2