import React from "react";
import {Navigate} from "react-router-dom";

//Dashboard
import DashboardCrm from "../pages/DashboardCrm";
import DashboardProject from "../pages/DashboardProject";


//Forms
import BasicElements from "../pages/Forms/BasicElements/BasicElements";
import FormSelect from "../pages/Forms/FormSelect/FormSelect";
import FormEditor from "../pages/Forms/FormEditor/FormEditor";
import CheckBoxAndRadio from "../pages/Forms/CheckboxAndRadio/CheckBoxAndRadio";
import Masks from "../pages/Forms/Masks/Masks";
import FileUpload from "../pages/Forms/FileUpload/FileUpload";
import FormPickers from "../pages/Forms/FormPickers/FormPickers";
import FormRangeSlider from "../pages/Forms/FormRangeSlider/FormRangeSlider";
import Formlayouts from "../pages/Forms/FormLayouts/Formlayouts";
import FormValidation from "../pages/Forms/FormValidation/FormValidation";
import FormWizard from "../pages/Forms/FormWizard/FormWizard";
import FormAdvanced from "../pages/Forms/FormAdvanced/FormAdvanced";
import Select2 from "../pages/Forms/Select2/Select2";

//Tables
import BasicTables from '../pages/Tables/BasicTables/BasicTables';
import ListTables from '../pages/Tables/ListTables/ListTables';
import ReactTable from "../pages/Tables/ReactTables";

//Icon pages
import RemixIcons from "../pages/Icons/RemixIcons/RemixIcons";
import BoxIcons from "../pages/Icons/BoxIcons/BoxIcons";
import MaterialDesign from "../pages/Icons/MaterialDesign/MaterialDesign";
import FeatherIcons from "../pages/Icons/FeatherIcons/FeatherIcons";
import LineAwesomeIcons from "../pages/Icons/LineAwesomeIcons/LineAwesomeIcons";
//pages
import Starter from '../pages/Pages/Starter/Starter';
import SimplePage from '../pages/Pages/Profile/SimplePage/SimplePage';
import Settings from '../pages/Pages/Profile/Settings/Settings';
import Team from '../pages/Pages/Team/Team';
import Timeline from '../pages/Pages/Timeline/Timeline';
import Faqs from '../pages/Pages/Faqs/Faqs';
import Pricing from '../pages/Pages/Pricing/Pricing';
import Gallery from '../pages/Pages/Gallery/Gallery';
import Maintenance from '../pages/Pages/Maintenance/Maintenance';
import ComingSoon from '../pages/Pages/ComingSoon/ComingSoon';
import SiteMap from '../pages/Pages/SiteMap/SiteMap';
//login
import Login from "../pages/Authentication/Login";
import ForgetPasswordPage from "../pages/Authentication/ForgetPassword";
import Logout from "../pages/Authentication/Logout";
import Register from "../pages/Authentication/Register";

//Charts
import LineCharts from "../pages/Charts/ApexCharts/LineCharts";
import AreaCharts from "../pages/Charts/ApexCharts/AreaCharts";
import ColumnCharts from "../pages/Charts/ApexCharts/ColumnCharts";
import BarCharts from "../pages/Charts/ApexCharts/BarCharts";
import MixedCharts from "../pages/Charts/ApexCharts/MixedCharts";
import TimelineCharts from "../pages/Charts/ApexCharts/TimelineCharts";
import CandlestickChart from "../pages/Charts/ApexCharts/CandlestickChart";
import BoxplotCharts from "../pages/Charts/ApexCharts/BoxplotCharts";
import BubbleChart from "../pages/Charts/ApexCharts/BubbleChart";
import ScatterCharts from "../pages/Charts/ApexCharts/ScatterCharts";
import HeatmapCharts from "../pages/Charts/ApexCharts/HeatmapCharts";
import TreemapCharts from "../pages/Charts/ApexCharts/TreemapCharts";
import PieCharts from "../pages/Charts/ApexCharts/PieCharts";
import RadialbarCharts from "../pages/Charts/ApexCharts/RadialbarCharts";
import RadarCharts from "../pages/Charts/ApexCharts/RadarCharts";
import PolarCharts from "../pages/Charts/ApexCharts/PolarCharts";

import ChartsJs from "../pages/Charts/ChartsJs/index";
import Echarts from "../pages/Charts/ECharts/index";

// User Profile
import UserProfile from "../pages/Authentication/user-profile";


import UiLink from "../pages/BaseUi/UiLink/UiLink";
import RangeArea from "../pages/Charts/ApexCharts/RangeAreaCharts/Index";
import FunnelChart from "../pages/Charts/ApexCharts/FunnelCharts/index";
import NewDatabase from "../pages/Databases/NewDatabase";
import ProjectList from "../pages/Projects/ProjectList";
import CreateProject from "../pages/Projects/CreateProject";
import ProjectOverview from "../pages/Projects/ProjectOverview";
import CreateDatabase from "../pages/Databases/CreateDatabase";
import DatabaseList from "../pages/Databases/DatabaseList";
import CollectionList from "../pages/Collections/CollectionList";
import IndexList from "../pages/Indexes";
import CompareIndexes from "../pages/Indexes/CompareIndexes";

const authProtectedRoutes = [
    {path: "/dashboard-crm", component: <DashboardCrm/>},
    {path: "/dashboard-projects", component: <DashboardProject/>},

    {path: "/new-database", component: <NewDatabase/>},
    {path: "/create-database", component: <CreateDatabase/>},
    {path: "/databases", component: <DatabaseList/>},

    {path: "/collections", component: <CollectionList/>},
    {path: "/indexes", component: <IndexList/>},
    {path: "/compare", component: <CompareIndexes/>},


    //Icons
    {path: "/icons-remix", component: <RemixIcons/>},
    {path: "/icons-boxicons", component: <BoxIcons/>},
    {path: "/icons-materialdesign", component: <MaterialDesign/>},
    {path: "/icons-feather", component: <FeatherIcons/>},
    {path: "/icons-lineawesome", component: <LineAwesomeIcons/>},

    {path: "/pages-profile", component: <SimplePage/>},
    {path: "/pages-profile-settings", component: <Settings/>},

    //User Profile
    {path: "/profile", component: <UserProfile/>},


    // this route should be at the end of all other routes
    // eslint-disable-next-line react/display-name
    {
        path: "/",
        exact: true,
        component: <Navigate to="/databases"/>,
    },
    {path: "*", component: <Navigate to="/databases"/>},
];

const publicRoutes = [
    // Authentication Page
    {path: "/logout", component: <Logout/>},
    {path: "/login", component: <Login/>},
    {path: "/forgot-password", component: <ForgetPasswordPage/>},
    {path: "/register", component: <Register/>},

];

export {authProtectedRoutes, publicRoutes};