import {createSlice} from "@reduxjs/toolkit";
// import { getCollectionList, addCollectionList, updateCollectionList, deleteCollectionList } from './thunk';
import {createCollection, deleteCollectionList, getCollectionList, updateCollection} from './thunk';

export const initialState = {
    collectionLists: [],
    reload: 0,
    error: {},
};


const CollectionsSlice = createSlice({
    name: 'CollectionsSlice',
    initialState,
    reducer: {},
    extraReducers: (builder) => {
        builder.addCase(getCollectionList.fulfilled, (state, action) => {
            state.collectionLists = action.payload;
        });
        builder.addCase(getCollectionList.rejected, (state, action) => {
            // state.error = action.payload.error || null;
            state.error = action.payload || null;
        });

        //
        builder.addCase(createCollection.fulfilled, (state, action) => {
            state.reload += 1;
        });
        builder.addCase(createCollection.rejected, (state, action) => {
            state.error = action.payload || null;
        });
        builder.addCase(updateCollection.fulfilled, (state, action) => {
            state.reload += 1;
        });
        builder.addCase(updateCollection.rejected, (state, action) => {
            state.error = action.payload || null;
        });
        builder.addCase(deleteCollectionList.fulfilled, (state, action) => {
            if (action.payload.data) {
                state.collectionLists.records = state.collectionLists.records.filter(collection => collection.id.toString() !== action.payload.id.toString());
                state.collectionLists.paging.total -= 1
            }
            state.reload += 1
        });
        builder.addCase(deleteCollectionList.rejected, (state, action) => {
            state.error = action.payload.error || null;
        });
    }
});

const CollectionSlice = createSlice({
    name: "Collection",
    initialState,
    reducers: {
        postCollectionSuccess(state, action) {
            state.success = true;
        },
        postCollectionError(state, action) {
            state.error = action.payload
        },
    },
});

export const {
    postCollectionSuccess,
    postCollectionError
} = CollectionSlice.actions

export default CollectionsSlice.reducer;