//Include Both Helper File with needed methods
import {getFirebaseBackend} from "../../../helpers/firebase_helper";
import {postFakeLogin, postFakeProfile, getProfile, postJwtProfile} from "../../../helpers/fakebackend_helper";

// action
import {profileSuccess, profileError, editProfileChange, resetProfileFlagChange, getProfileSuccess,} from "./reducer";
import {apiError, loginSuccess} from "../login/reducer";
import {setAuthorization} from "../../../helpers/api_helper";

const fireBaseBackend = getFirebaseBackend();

export const getProfileUser = () => async (dispatch) => {
    try {
        let response;

        let token = JSON.parse(localStorage.getItem("tokens")).access_token
        setAuthorization(token);

        response = getProfile()
        let dataResponse = await response
        if (dataResponse) {
            let data = dataResponse
            localStorage.setItem("authUser", JSON.stringify(data));
            dispatch(getProfileSuccess(data));
        }

    } catch (error) {
        dispatch(apiError(error));
    }
}

export const editProfile = (user) => async (dispatch) => {
    try {
        let response;

        let token = JSON.parse(localStorage.getItem("tokens")).access_token
        setAuthorization(token);
        response = postFakeProfile(user);

        const data = await response;

        if (data) {
            dispatch(profileSuccess(data));
        }


    } catch (error) {
        dispatch(profileError(error));
    }
};

export const resetProfileFlag = () => {
    try {
        const response = resetProfileFlagChange();
        return response;
    } catch (error) {
        return error;
    }
};