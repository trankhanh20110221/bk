import {createSlice} from "@reduxjs/toolkit";
// import { getDatabaseList, addDatabaseList, updateDatabaseList, deleteDatabaseList } from './thunk';
import {createDatabase, deleteDatabaseList, getDatabaseList, updateDatabase} from './thunk';

export const initialState = {
    databaseLists: [],
    databaseCurrent: null,
    reload: 0,
    error: {},
    loading: false,
};


const DatabasesSlice = createSlice({
    name: 'DatabasesSlice',
    initialState,
    reducers: {
    },
    extraReducers: (builder) => {
        builder.addCase(getDatabaseList.fulfilled, (state, action) => {
            state.databaseLists = action.payload;
        });
        builder.addCase(getDatabaseList.rejected, (state, action) => {
            // state.error = action.payload.error || null;
            state.error = action.payload || null;
        });

        // add more reducers here
        //
        builder.addCase(createDatabase.fulfilled, (state, action) => {
            state.reload += 1;
            state.loading = false;
        });
        builder.addCase(createDatabase.rejected, (state, action) => {
            state.error = action.payload || null;
            state.loading = false;
        });
        builder.addCase(updateDatabase.fulfilled, (state, action) => {
            state.reload += 1;
            state.loading = false;
        });
        builder.addCase(updateDatabase.rejected, (state, action) => {
            state.error = action.payload || null;
            state.loading = false;
        });
        builder.addCase(deleteDatabaseList.fulfilled, (state, action) => {
            if (action.payload.data) {
                state.databaseLists.records = state.databaseLists.records.filter(database => database.id.toString() !== action.payload.id.toString());
                state.databaseLists.paging.total -= 1
            }
            state.reload += 1
        });
        builder.addCase(deleteDatabaseList.rejected, (state, action) => {
            state.error = action.payload.error || null;
        });
    }
});

export default DatabasesSlice.reducer;