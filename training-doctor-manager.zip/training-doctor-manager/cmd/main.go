package main

import (
	"log"

	"training-doctor-manager/cmd/launcher"
	"training-doctor-manager/common/config"
	"training-doctor-manager/common/logging"
)

func main() {
	logging.InitLogger()
	cfg := config.LoadConfig()
	db := launcher.ConnectDatabase(cfg)
	app := launcher.NewApplication()
	launcher.SetupRoute(app, db, cfg)
	log.Fatal(app.Listen(":" + cfg.App.Port))
}
