package main

import (
	"log"

	"training-doctor-manager/cmd/launcher"
	"training-doctor-manager/common/logging"
	"training-doctor-manager/config"
)

func main() {
	logging.InitLogger()
	cfg := config.LoadConfig()
	db := launcher.ConnectDatabase(cfg)
	app := launcher.NewApplication()
	launcher.SetupRoute(app, db, cfg)
	log.Fatal(app.Listen(":" + cfg.App.Port))
}
