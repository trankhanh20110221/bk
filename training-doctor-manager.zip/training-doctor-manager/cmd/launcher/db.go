package launcher

import (
	"context"
	"log"

	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"training-doctor-manager/common/config"
)

func ConnectDatabase(cfg *config.Config) *mongo.Database {
	ctx, cancel := context.WithTimeout(context.Background(), cfg.Mongo.Timeout)
	clientOptions := NewClientOptions(cfg.Mongo.Uri)

	client, err := mongo.Connect(ctx, clientOptions)
	if err != nil {
		cancel()
		log.Fatal("Database Connection Error: ", err)
	}

	err = client.Ping(ctx, nil)
	if err != nil {
		log.Fatal("Database Connection Error: ", err)
	}

	db := client.Database(cfg.Mongo.Database)
	defer cancel()
	return db
}

func NewClientOptions(uri string) *options.ClientOptions {
	loggerOptions := options.
		Logger().
		SetComponentLevel(options.LogComponentCommand, options.LogLevelDebug)

	clientOptions := options.
		Client().
		ApplyURI(uri).
		SetLoggerOptions(loggerOptions)

	return clientOptions
}
