package launcher

import (
	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
	"go.mongodb.org/mongo-driver/mongo"
	"training-doctor-manager/config"
	"training-doctor-manager/middleware"
	AccountHdl "training-doctor-manager/pkg/account/handler"
	AccountRepo "training-doctor-manager/pkg/account/repository"
	AccountUc "training-doctor-manager/pkg/account/usecase"
	DatabaseHdl "training-doctor-manager/pkg/database/handler"
	DatabaseRepo "training-doctor-manager/pkg/database/repository"
	DatabaseUc "training-doctor-manager/pkg/database/usecase"
	IndexHdl "training-doctor-manager/pkg/index/handler"
	IndexRepo "training-doctor-manager/pkg/index/repository"
	IndexUc "training-doctor-manager/pkg/index/usecase"
	syncinghandler "training-doctor-manager/pkg/syncing/handler"
	SyncingRepo "training-doctor-manager/pkg/syncing/repository"
	"training-doctor-manager/pkg/syncing/usecase"
	TokenHdl "training-doctor-manager/pkg/token/handler"
	TokenRepo "training-doctor-manager/pkg/token/repository"
	TokenUc "training-doctor-manager/pkg/token/usecase"
	"training-doctor-manager/util"
)

func SetupRoute(app *fiber.App, db *mongo.Database, cfg *config.Config) {
	appValidator := validator.New()
	util.RegisterCustomValidations(appValidator)

	tokenRepo := TokenRepo.NewAuthTokenRepository(db)
	accountRepo := AccountRepo.NewAccountRepository(db)
	databaseRepo := DatabaseRepo.NewDatabaseRepository(db)
	indexRepo := IndexRepo.NewIndexRepository(db)
	syncingRepo := SyncingRepo.NewSyncingRepository(db)

	accountUc := AccountUc.NewAccountUsecase(accountRepo, tokenRepo, cfg)
	tokenUc := TokenUc.NewTokenUsecase(tokenRepo, accountRepo, cfg)
	databaseUc := DatabaseUc.NewDatabaseUsecase(databaseRepo, indexRepo)
	indexUc := IndexUc.NewIndexUsecase(indexRepo, databaseRepo, syncingRepo)
	syncingUc := usecase.NewSyncingUsecase(syncingRepo, databaseRepo)

	tokenHdl := TokenHdl.NewTokenHandler(tokenUc, appValidator)
	accountHdl := AccountHdl.NewAccountHandler(accountUc, appValidator)
	databaseHdl := DatabaseHdl.NewDatabaseHandler(databaseUc, appValidator)
	indexHdl := IndexHdl.NewIndexHandler(indexUc, appValidator)
	syncingHdl := syncinghandler.NewSyncingHandler(syncingUc, appValidator)

	middlewares := middleware.NewMiddlewareManager(cfg, accountRepo, tokenRepo)

	api := app.Group("/doctor-manager/api/v1")

	api.Post("/signup", accountHdl.Signup())
	api.Post("/login", accountHdl.Login())
	api.Get("/profile", middlewares.RequiredAuth(), accountHdl.GetProfile())
	api.Put("/profile", middlewares.RequiredAuth(), accountHdl.UpdateAccount())
	api.Post("/tokens/refresh", tokenHdl.RefreshToken())

	databases := api.Group("/databases", middlewares.RequiredAuth())
	{
		databases.Get("/", databaseHdl.GetAllDatabase())
		databases.Get("/:id", databaseHdl.GetOneDatabase())
		databases.Post("/", databaseHdl.CreateDatabase())
		databases.Put("/:id", databaseHdl.UpdateDatabase())
		databases.Delete("/:id", databaseHdl.DeleteDatabase())
		databases.Delete("/", databaseHdl.DeleteDatabases())
		databases.Get("/:id/collections/", databaseHdl.ListCollections())
		databases.Post("/:id/collections/", databaseHdl.CreateCollection())
		databases.Delete("/:id/collections/", databaseHdl.DeleteCollection())
	}

	indexes := api.Group("/indexes", middlewares.RequiredAuth())
	{
		indexes.Get("/", indexHdl.GetIndexes())
		indexes.Get("/:index_id", indexHdl.GetIndex())
		indexes.Post("/", indexHdl.CreateIndex())
		indexes.Put("/:index_id", indexHdl.UpdateIndex())
		indexes.Delete("/:id", indexHdl.DeleteIndex())
		indexes.Delete("/", indexHdl.DeleteIndexes())
		indexes.Post("/syncing/collection", indexHdl.SyncIndexesByCollection())
		indexes.Post("/syncing/database", indexHdl.SyncIndexesByDatabase())
		indexes.Post("/comparing/collection", indexHdl.CompareIndexesByCollection())
		indexes.Post("/comparing/database", indexHdl.CompareIndexesByDatabase())
	}

	syncing := api.Group("/syncing", middlewares.RequiredAuth())
	{
		syncing.Get("/", syncingHdl.GetAllSyncing())
		syncing.Delete("/:id", syncingHdl.DeleteSyncing())
	}

}
