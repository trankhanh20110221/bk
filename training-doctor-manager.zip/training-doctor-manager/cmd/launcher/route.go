package launcher

import (
	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
	"go.mongodb.org/mongo-driver/mongo"
	"training-doctor-manager/common/config"
	accountController "training-doctor-manager/pkg/controllers/account"
	databaseController "training-doctor-manager/pkg/controllers/database"
	indexController "training-doctor-manager/pkg/controllers/index"
	syncController "training-doctor-manager/pkg/controllers/syncing"
	tokenController "training-doctor-manager/pkg/controllers/token"
	accountHandler "training-doctor-manager/pkg/handlers/account"
	databaseHandler "training-doctor-manager/pkg/handlers/database"
	indexHandler "training-doctor-manager/pkg/handlers/index"
	syncHandler "training-doctor-manager/pkg/handlers/syncing"
	tokenHandler "training-doctor-manager/pkg/handlers/token"
	"training-doctor-manager/pkg/middleware"
	"training-doctor-manager/pkg/repository"
	"training-doctor-manager/util"
)

func SetupRoute(app *fiber.App, db *mongo.Database, cfg *config.Config) {
	appValidator := validator.New()
	util.RegisterCustomValidations(appValidator)

	tokenRepo := repository.NewAuthTokenRepository(db)
	accountRepo := repository.NewAccountRepository(db)
	databaseRepo := repository.NewDatabaseRepository(db)
	indexRepo := repository.NewIndexRepository(db)
	syncingRepo := repository.NewSyncingRepository(db)

	accountCtrl := accountController.New(accountRepo, tokenRepo, cfg)
	tokenCtrl := tokenController.New(tokenRepo, accountRepo, cfg)
	databaseCtrl := databaseController.New(databaseRepo, indexRepo)
	indexCtrl := indexController.New(indexRepo, databaseRepo, syncingRepo)
	syncCtrl := syncController.New(syncingRepo, databaseRepo)

	tokenHdl := tokenHandler.NewHandler(tokenCtrl, appValidator)
	accountHdl := accountHandler.NewHandler(accountCtrl, appValidator)
	databaseHdl := databaseHandler.NewHandler(databaseCtrl, appValidator)
	indexHdl := indexHandler.NewHandler(indexCtrl, appValidator)
	syncingHdl := syncHandler.NewHandler(syncCtrl, appValidator)

	middlewares := middleware.NewMiddlewareManager(cfg, accountRepo, tokenRepo)

	api := app.Group("/doctor-manager/api/v1")

	api.Post("/signup", accountHdl.Signup())
	api.Post("/login", accountHdl.Login())
	api.Get("/profile", middlewares.RequiredAuth(), accountHdl.GetProfile())
	api.Put("/profile", middlewares.RequiredAuth(), accountHdl.UpdateAccount())
	api.Post("/tokens/refresh", tokenHdl.RefreshToken())

	databases := api.Group("/databases", middlewares.RequiredAuth())
	{
		databases.Get("/", databaseHdl.GetAllDatabase())
		databases.Get("/:id", databaseHdl.GetOneDatabase())
		databases.Post("/", databaseHdl.CreateDatabase())
		databases.Put("/:id", databaseHdl.UpdateDatabase())
		databases.Delete("/:id", databaseHdl.DeleteDatabase())
		databases.Delete("/", databaseHdl.DeleteDatabases())
		databases.Get("/:id/collections/", databaseHdl.ListCollections())
		databases.Post("/:id/collections/", databaseHdl.CreateCollection())
		databases.Delete("/:id/collections/", databaseHdl.DeleteCollection())
	}

	indexes := api.Group("/indexes", middlewares.RequiredAuth())
	{
		indexes.Get("/", indexHdl.GetIndexes())
		indexes.Get("/:index_id", indexHdl.GetIndex())
		indexes.Post("/", indexHdl.CreateIndex())
		indexes.Put("/:index_id", indexHdl.UpdateIndex())
		indexes.Delete("/:id", indexHdl.DeleteIndex())
		indexes.Delete("/", indexHdl.DeleteIndexes())
		indexes.Post("/syncing/collection", indexHdl.SyncIndexesByCollection())
		indexes.Post("/syncing/database", indexHdl.SyncIndexesByDatabase())
		indexes.Post("/comparing/collection", indexHdl.CompareIndexesByCollection())
		indexes.Post("/comparing/database", indexHdl.CompareIndexesByDatabase())
	}

	syncing := api.Group("/syncing", middlewares.RequiredAuth())
	{
		syncing.Get("/", syncingHdl.GetAllSyncing())
		syncing.Delete("/:id", syncingHdl.DeleteSyncing())
	}

}
