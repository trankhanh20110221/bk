package launcher

import (
	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
	"github.com/gofiber/fiber/v2/middleware/logger"
	recoverFiber "github.com/gofiber/fiber/v2/middleware/recover"
	"training-doctor-manager/common"
)

func NewApplication() *fiber.App {
	config := fiber.Config{
		ErrorHandler: common.CustomErrorHandler,
	}
	app := fiber.New(config)

	app.Use(logger.New())
	app.Use(cors.New())
	app.Use(recoverFiber.New())

	return app
}
