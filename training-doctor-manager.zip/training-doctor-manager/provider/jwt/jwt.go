package jwt

import (
	"crypto/rsa"
	"errors"
	"net/http"

	"github.com/golang-jwt/jwt/v5"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"training-doctor-manager/common"
)

type CustomPayload struct {
	AccountID primitive.ObjectID `json:"account_id"`
	TokenType int                `json:"token_type"`
}

type CustomClaims struct {
	jwt.RegisteredClaims
	Payload CustomPayload `json:"payload"`
}

func CreateToken(data CustomPayload, tokenID string, signKey *rsa.PrivateKey, exp *jwt.NumericDate) (string, error) {
	t := jwt.New(jwt.GetSigningMethod(jwt.SigningMethodRS256.Name))
	t.Claims = &CustomClaims{
		Payload: data,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: exp,
			ID:        tokenID,
		},
	}

	token, err := t.SignedString(signKey)
	if err != nil {
		return "", common.NewErrorResponse(http.StatusUnauthorized, errors.New("error encoding token"), "Unauthorized", "ErrUnauthorized")
	}
	return token, nil
}

func ExtractDataFromToken(requestToken string, tokenType int, verifyKey *rsa.PublicKey) (*CustomClaims, error) {
	token, err := jwt.ParseWithClaims(requestToken, &CustomClaims{}, func(token *jwt.Token) (interface{}, error) {
		return verifyKey, nil
	})

	if err != nil {
		return nil, err
	}
	claims, ok := token.Claims.(*CustomClaims)

	if claims.Payload.TokenType != tokenType {
		return nil, common.NewErrorResponse(http.StatusUnauthorized, errors.New("invalid token"), "Unauthorized", "ErrUnauthorized")
	}
	if !ok {
		return nil, common.NewErrorResponse(http.StatusUnauthorized, errors.New("invalid token"), "Unauthorized", "ErrUnauthorized")
	}
	return claims, nil
}
