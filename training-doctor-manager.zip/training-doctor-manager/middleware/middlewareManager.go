package middleware

import (
	"training-doctor-manager/config"
	"training-doctor-manager/pkg/account/repository"
	tokenRepository "training-doctor-manager/pkg/token/repository"
)

type MWManager struct {
	cfg       *config.Config
	TokenRepo tokenRepository.AuthTokenRepository
}

func NewMiddlewareManager(cfg *config.Config, accountRepo repository.AccountRepository, tokenRepo tokenRepository.AuthTokenRepository) *MWManager {
	return &MWManager{cfg: cfg, TokenRepo: tokenRepo}
}
