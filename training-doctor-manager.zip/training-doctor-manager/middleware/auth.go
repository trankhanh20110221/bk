package middleware

import (
	"errors"
	"net/http"
	"strings"

	"github.com/gofiber/fiber/v2"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"training-doctor-manager/common"
	"training-doctor-manager/pkg/account/model"
	"training-doctor-manager/provider/jwt"
	"training-doctor-manager/util/local"
)

func ExtractTokenFromContext(c *fiber.Ctx) (string, error) {
	bearerToken := c.Get("Authorization")
	if bearerToken == "" {
		return "", common.NewErrorResponse(http.StatusBadRequest, errors.New("invalid request"), "Invalid Authorization header format", "ErrInvalidRequest")
	}

	parts := strings.Split(bearerToken, " ")
	if len(parts) != 2 || parts[0] != "Bearer" || parts[1] == "" {
		return "", common.NewErrorResponse(http.StatusBadRequest, errors.New("invalid request"), "Invalid Authorization header format", "ErrInvalidRequest")
	}
	return parts[1], nil
}

func (m *MWManager) RequiredAuth() fiber.Handler {
	return func(c *fiber.Ctx) error {
		token, err := ExtractTokenFromContext(c)
		if err != nil {
			return err
		}

		tokenRequest, err := jwt.ExtractDataFromToken(token, common.TypeAccessToken, m.cfg.Jwt.VerifyKey)
		if err != nil {
			return common.NewErrorResponse(http.StatusUnauthorized, err, "Unauthorized", "ErrUnauthorized")
		}

		tokenOID, err := primitive.ObjectIDFromHex(tokenRequest.RegisteredClaims.ID)
		if err != nil {
			return common.NewErrorResponse(http.StatusUnauthorized, err, "Unauthorized", "ErrUnauthorized")
		}

		if _, err = m.TokenRepo.GetTokenByTokenId(c.Context(), tokenOID); err != nil {
			return common.NewErrorResponse(http.StatusUnauthorized, err, "Unauthorized", "ErrUnauthorized")
		}

		local.New(c).SetUser(&model.Account{
			ID: tokenRequest.Payload.AccountID,
		})
		return c.Next()
	}
}
