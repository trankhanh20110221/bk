package util

import (
	"errors"
	"fmt"
	"strings"

	"training-doctor-manager/pkg/index/model"

	"github.com/go-playground/validator/v10"
)

func RegisterCustomValidations(validator *validator.Validate) {
	_ = validator.RegisterValidation("mongo_uri", ValidateConnectionUri)
	_ = validator.RegisterValidation("mongo_index_value", ValidateMongoIndexValue)
	_ = validator.RegisterValidation("mongo_index_field", ValidateMongoIndexField)
	_ = validator.RegisterValidation("mongo_index_default_invalid", ValidateMongoIndexDefault)
	_ = validator.RegisterValidation("no_space", ValidateNoSpace)
}

func ValidateConnectionUri(fl validator.FieldLevel) bool {
	data := fl.Field().String()
	return data == "" || strings.HasPrefix(data, "mongodb://") || strings.HasPrefix(data, "mongodb+srv://")
}

func ValidateNoSpace(fl validator.FieldLevel) bool {
	data := fl.Field().String()
	data = strings.TrimSpace(data)
	return !strings.Contains(data, " ")
}

func ValidateMongoIndexValue(fl validator.FieldLevel) bool {
	data := fl.Field().Int()
	return data == 1 || data == -1
}

func ValidateMongoIndexDefault(fl validator.FieldLevel) bool {
	data := fl.Field().String()
	return data != "_id"
}

func ValidateMongoIndexField(fl validator.FieldLevel) bool {
	data := fl.Field().Interface().([]*model.IndexKeyRequest)
	keys := make(map[string]bool)
	for _, key := range data {
		if keys[key.Field] {
			return false
		}
		keys[key.Field] = true
	}
	return true
}

func ParseValidationMessage(err error) string {
	var errs validator.ValidationErrors
	if errors.As(err, &errs) {
		messages := make([]string, len(errs))
		for i, e := range errs {
			messages[i] = fmt.Sprintf("Field validation for '%s' failed on the '%s' tag", e.Field(), e.Tag())
		}
		return strings.Join(messages, ", ")
	}
	return err.Error()
}
