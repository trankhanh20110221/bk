package asyncjob

import (
	"context"
)

type group struct {
	jobs         []Job
	isConcurrent bool
}

type Group interface {
	Run(ctx context.Context) error
	runJob(ctx context.Context, job Job) error
}

func NewGroup(isConcurrent bool, jobs ...Job) Group {
	return &group{
		isConcurrent: isConcurrent,
		jobs:         jobs,
	}
}

func (g *group) Run(ctx context.Context) error {
	if g.isConcurrent {
		numJobs := len(g.jobs)

		errChan := make(chan error, numJobs)
		for _, jobIndex := range g.jobs {
			go func(job Job) {
				defer Recovery()
				errChan <- g.runJob(ctx, job)
			}(jobIndex)
		}

		for range numJobs {
			if err := <-errChan; err != nil {
				return err
			}
		}
	} else {
		for _, jobIndex := range g.jobs {
			if err := g.runJob(ctx, jobIndex); err != nil {
				return err
			}
		}
	}

	return nil
}

func (g *group) runJob(ctx context.Context, job Job) error {
	if err := job.Execute(ctx); err != nil {
		for {
			if job.State() == StateRetryFailed {
				return err
			}

			if job.Retry(ctx) == nil {
				return nil
			}
		}
	}

	return nil
}
