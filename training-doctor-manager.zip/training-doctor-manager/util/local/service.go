package local

import (
	"training-doctor-manager/pkg/account/model"
)

func (s service) SetUser(value *model.Account) {
	s.context.Locals(KeyUser, value)
}

func (s service) GetUser() *model.Account {
	if value, ok := s.context.Locals(KeyUser).(*model.Account); ok {
		return value
	}
	return nil
}
