package local

import (
	"github.com/gofiber/fiber/v2"
	"training-doctor-manager/pkg/models"
)

type Service interface {
	GetUser() *models.Account
	SetUser(value *models.Account)
}

const (
	KeyUser = "current_user"
)

type service struct {
	context *fiber.Ctx
}

func New(ctx *fiber.Ctx) Service {
	return &service{context: ctx}
}
