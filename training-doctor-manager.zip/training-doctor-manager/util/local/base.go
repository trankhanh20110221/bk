package local

import (
	"training-doctor-manager/pkg/account/model"

	"github.com/gofiber/fiber/v2"
)

type Service interface {
	GetUser() *model.Account
	SetUser(value *model.Account)
}

const (
	KeyUser = "current_user"
)

type service struct {
	context *fiber.Ctx
}

func New(ctx *fiber.Ctx) Service {
	return &service{context: ctx}
}
