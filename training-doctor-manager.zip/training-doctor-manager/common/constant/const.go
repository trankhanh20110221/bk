package constant

const (
	TypeAccessToken int = iota + 1
	TypeRefreshToken
)

const (
	TypeSyncCollection int = iota + 1
	TypeSyncDatabase
)

const (
	OptionSyncForward = iota + 1
	OptionSyncBack
)
