package constant

const (
	MongoErrNamespaceNotFound = 26
	MongoErrIndexNotFound     = 27
)
