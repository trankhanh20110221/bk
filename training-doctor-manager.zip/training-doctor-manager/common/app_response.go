package common

import (
	"github.com/gofiber/fiber/v2"
)

type SuccessRes struct {
	Data any `json:"data"`
}

func NewSuccessRes(data any) *SuccessRes {
	return &SuccessRes{Data: data}
}

func SuccessResponse(ctx *fiber.Ctx, status int, data any) error {
	return ctx.Status(status).JSON(NewSuccessRes(data))
}
