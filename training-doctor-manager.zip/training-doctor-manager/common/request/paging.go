package request

const (
	minLimit = 10
	maxLimit = 100
)

type Paging struct {
	Page  int   `json:"page" query:"page"`
	Limit int   `json:"limit" query:"limit"`
	Total int64 `json:"total" query:"-"`
}

func (p *Paging) Process() {
	if p.Page < 1 {
		p.Page = 1
	}

	if p.Limit <= 0 {
		p.Limit = minLimit
	}

	if p.Limit >= maxLimit {
		p.Limit = maxLimit
	}
}
