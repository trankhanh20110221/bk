package common

import (
	"errors"
	"strings"

	"github.com/gofiber/fiber/v2"
)

const (
	KeyErrorInternal = "ErrInternal"
)

type AppError struct {
	RootErr    error  `json:"-"`
	Message    string `json:"message"`
	Log        string `json:"-"`
	Key        string `json:"error_key"`
	StatusCode int    `json:"status_code"`
}

func NewErrorResponse(status int, root error, msg, key string) *AppError {
	return &AppError{
		StatusCode: status,
		RootErr:    root,
		Message:    msg,
		Log:        root.Error(),
		Key:        key,
	}
}

func (e *AppError) Error() string {
	return e.RootErr.Error()
}

func CustomErrorHandler(c *fiber.Ctx, err error) error {
	code := fiber.StatusInternalServerError
	key := KeyErrorInternal
	message := err.Error()

	var e *AppError
	if errors.As(err, &e) {
		code = e.StatusCode
		message = e.Message
		key = e.Key
	}

	c.Set(fiber.HeaderContentType, fiber.MIMEApplicationJSON)
	return c.Status(code).JSON(&fiber.Map{
		"error_key": key,
		"message":   message,
	})
}

const TotalPart = 2

func ParseIndexFromMessage(message string) string {
	parts := strings.Split(message, " dup key")
	if len(parts) == 0 {
		return ""
	}
	subParts := strings.Split(parts[0], "index: ")
	if len(subParts) < TotalPart {
		return ""
	}
	return subParts[1]
}
