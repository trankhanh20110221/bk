package database

import (
	"context"
	"time"

	"training-doctor-manager/common/logging"
	"training-doctor-manager/pkg/models"
	"training-doctor-manager/pkg/repository"
	"training-doctor-manager/util"
)

var (
	logger = logging.GetLogger()
)

type controller struct {
	databaseRepo repository.DatabaseRepository
	indexRepo    repository.IndexRepository
}

func New(databaseRepository repository.DatabaseRepository, indexRepo repository.IndexRepository) Controller {
	return &controller{
		databaseRepo: databaseRepository,
		indexRepo:    indexRepo,
	}
}

type Controller interface {
	CreateDatabase(ctx context.Context, data models.DatabaseCreationRequest) (*models.DatabaseCreationResponse, error)
	GetOneDatabase(ctx context.Context, data models.DatabaseGetOneRequest) (*models.DatabaseGetOneResponse, error)
	GetAllDatabase(ctx context.Context, data models.DatabaseGetAllRequest) (*models.DatabaseGetAllResponse, error)
	UpdateDatabase(ctx context.Context, dataBody models.DatabaseUpdateBodyRequest, dataParam models.DatabaseUpdateParamRequest) (*models.DatabaseUpdateResponse, error)
	DeleteDatabase(ctx context.Context, data models.DatabaseDeletionParamRequest) (*models.DatabaseDeletionResponse, error)
	DeleteDatabases(ctx context.Context, dataRequest models.DatabaseManyDeletionRequest) (*models.DatabaseDeletionResponse, error)
	ListCollections(ctx context.Context, dataQuery models.CollectionListQueryRequest, dataParam models.CollectionListParamRequest) (*models.CollectionListResponse, error)
	CreateCollection(ctx context.Context, dataBody models.CollectionCreationBodyRequest, dataParam models.CollectionCreationParamRequest) (*models.CollectionCreationResponse, error)
	DeleteCollection(ctx context.Context, dataBody models.CollectionDeletionBodyRequest, dataParam models.CollectionDeletionParamRequest) (*models.CollectionDeletionResponse, error)
}

func (uc *controller) CreateCollection(ctx context.Context, dataBody models.CollectionCreationBodyRequest, dataParam models.CollectionCreationParamRequest) (*models.CollectionCreationResponse, error) {
	if _, err := uc.databaseRepo.GetDatabaseByID(ctx, dataParam.DatabaseID); err != nil {
		return nil, err
	}
	if _, err := uc.indexRepo.GetIndexByCollectionAndDatabaseID(ctx, dataBody.CollectionName, dataParam.DatabaseID); err == nil {
		return nil, err
	}
	if err := uc.indexRepo.CreateCollection(ctx, dataParam.DatabaseID, dataBody.CollectionName); err != nil {
		return nil, err
	}

	dataResponse := &models.CollectionCreationResponse{
		Status: true,
	}
	return dataResponse, nil
}

func (uc *controller) CreateDatabase(ctx context.Context, dataRequest models.DatabaseCreationRequest) (*models.DatabaseCreationResponse, error) {
	currentTime := time.Now()
	database := models.Database{
		Name:        dataRequest.Name,
		Description: dataRequest.Description,
		Uri:         dataRequest.Uri,
		DBName:      dataRequest.DBName,
		CreatedAt:   currentTime,
		UpdatedAt:   currentTime,
	}

	if dataRequest.TestConnection {
		if _, err := util.NewMongoDatabase(ctx, dataRequest.Uri, dataRequest.DBName); err != nil {
			return nil, err
		}
	}
	dataInserted, err := uc.databaseRepo.CreateDatabase(ctx, database)
	if err != nil {
		return nil, err
	}

	return &models.DatabaseCreationResponse{
		ID: dataInserted.ID.Hex(),
	}, nil
}

func (uc *controller) DeleteCollection(ctx context.Context, dataBody models.CollectionDeletionBodyRequest, dataParam models.CollectionDeletionParamRequest) (*models.CollectionDeletionResponse, error) {
	if _, err := uc.databaseRepo.GetDatabaseByID(ctx, dataParam.DatabaseID); err != nil {
		return nil, err
	}
	if _, err := uc.indexRepo.GetIndexByCollection(ctx, dataBody.CollectionName); err != nil {
		return nil, err
	}
	if err := uc.indexRepo.DeleteIndexesByCollection(ctx, dataBody.CollectionName); err != nil {
		return nil, err
	}

	return &models.CollectionDeletionResponse{
		Status: true,
	}, nil
}

func (uc *controller) DeleteDatabase(ctx context.Context, dataRequest models.DatabaseDeletionParamRequest) (*models.DatabaseDeletionResponse, error) {
	if _, err := uc.databaseRepo.GetDatabaseByID(ctx, dataRequest.ID); err != nil {
		return nil, err
	}
	if err := uc.databaseRepo.DeleteDatabaseByID(ctx, dataRequest.ID); err != nil {
		return nil, err
	}
	go func() {
		if err := uc.indexRepo.DeleteIndexesByDatabaseID(ctx, dataRequest.ID); err != nil {
			logger.Error().Err(err).Str("function", "DeleteDatabase").Str("functionInline", "uc.indexRepo.DeleteIndexesByDatabaseID").Msg("databaseUsecase")
		}
	}()

	return &models.DatabaseDeletionResponse{
		Status: true,
	}, nil
}

func (uc *controller) DeleteDatabases(ctx context.Context, dataRequest models.DatabaseManyDeletionRequest) (*models.DatabaseDeletionResponse, error) {
	if err := uc.databaseRepo.DeleteDatabasesByIDs(ctx, dataRequest.IDs); err != nil {
		return nil, err
	}
	go func() {
		if err := uc.indexRepo.DeleteIndexesByDatabaseIDs(ctx, dataRequest.IDs); err != nil {
			logger.Error().Err(err).Str("function", "DeleteDatabases").Str("functionInline", "uc.databaseRepo.DeleteDatabasesByIDs").Msg("databaseUsecase")
		}
	}()

	return &models.DatabaseDeletionResponse{
		Status: true,
	}, nil
}

func (uc *controller) GetAllDatabase(ctx context.Context, dataRequest models.DatabaseGetAllRequest) (*models.DatabaseGetAllResponse, error) {
	data, err := uc.databaseRepo.GetDatabases(ctx, &dataRequest.Paging, &dataRequest.Filter)
	if err != nil {
		return nil, err
	}
	if data == nil {
		data = []models.Database{}
	}

	dataResponse := &models.DatabaseGetAllResponse{
		Records: data,
		Paging:  &dataRequest.Paging,
	}
	return dataResponse, nil
}

func (uc *controller) GetOneDatabase(ctx context.Context, dataRequest models.DatabaseGetOneRequest) (*models.DatabaseGetOneResponse, error) {
	data, err := uc.databaseRepo.GetDatabaseByID(ctx, dataRequest.ID)
	if err != nil {
		return nil, err
	}

	return &models.DatabaseGetOneResponse{
		Name:        data.Name,
		Description: data.Description,
		Uri:         data.Uri,
		DBName:      data.DBName,
		CreatedAt:   data.CreatedAt,
		UpdatedAt:   data.UpdatedAt,
	}, nil
}

func (uc *controller) ListCollections(ctx context.Context, dataQuery models.CollectionListQueryRequest, dataParam models.CollectionListParamRequest) (*models.CollectionListResponse, error) {
	if _, err := uc.databaseRepo.GetDatabaseByID(ctx, dataParam.DatabaseID); err != nil {
		return nil, err
	}
	data, err := uc.indexRepo.ListCollections(ctx, dataParam.DatabaseID, &dataQuery.Paging, &dataQuery.Filter)
	if err != nil {
		return nil, err
	}

	if data == nil {
		data = []*models.CollectionResponse{}
	}
	return &models.CollectionListResponse{
		Records: data,
		Paging:  &dataQuery.Paging,
	}, nil
}

func (uc *controller) UpdateDatabase(ctx context.Context, dataBody models.DatabaseUpdateBodyRequest, dataParam models.DatabaseUpdateParamRequest) (*models.DatabaseUpdateResponse, error) {
	dataUpdate := models.Database{
		ID:          dataParam.ID,
		Name:        dataBody.Name,
		Description: dataBody.Description,
		Uri:         dataBody.Uri,
		DBName:      dataBody.DBName,
		UpdatedAt:   time.Now(),
	}
	if _, err := uc.databaseRepo.GetDatabaseByID(ctx, dataParam.ID); err != nil {
		return nil, err
	}
	if dataBody.TestConnection {
		if _, err := util.NewMongoDatabase(ctx, dataBody.Uri, dataBody.DBName); err != nil {
			return nil, err
		}
	}

	if err := uc.databaseRepo.UpdateDatabaseByID(ctx, dataUpdate.ID, dataUpdate); err != nil {
		return nil, err
	}

	return &models.DatabaseUpdateResponse{
		Status: true,
	}, nil
}
