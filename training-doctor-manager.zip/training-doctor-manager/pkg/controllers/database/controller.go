package database

import (
	"context"
	"time"

	"training-doctor-manager/common/logging"
	DatabaseRepo "training-doctor-manager/pkg/database/repository"
	IndexRepo "training-doctor-manager/pkg/index/repository"
	"training-doctor-manager/util"

	"training-doctor-manager/pkg/database/model"
)

var (
	logger = logging.GetLogger()
)

type controller struct {
	databaseRepo DatabaseRepo.DatabaseRepository
	indexRepo    IndexRepo.IndexRepository
}

func New(databaseRepository DatabaseRepo.DatabaseRepository, indexRepo IndexRepo.IndexRepository) Controller {
	return &controller{
		databaseRepo: databaseRepository,
		indexRepo:    indexRepo,
	}
}

type Controller interface {
	CreateDatabase(ctx context.Context, data model.DatabaseCreationRequest) (*model.DatabaseCreationResponse, error)
	GetOneDatabase(ctx context.Context, data model.DatabaseGetOneRequest) (*model.DatabaseGetOneResponse, error)
	GetAllDatabase(ctx context.Context, data model.DatabaseGetAllRequest) (*model.DatabaseGetAllResponse, error)
	UpdateDatabase(ctx context.Context, dataBody model.DatabaseUpdateBodyRequest, dataParam model.DatabaseUpdateParamRequest) (*model.DatabaseUpdateResponse, error)
	DeleteDatabase(ctx context.Context, data model.DatabaseDeletionParamRequest) (*model.DatabaseDeletionResponse, error)
	DeleteDatabases(ctx context.Context, dataRequest model.DatabaseManyDeletionRequest) (*model.DatabaseDeletionResponse, error)
	ListCollections(ctx context.Context, dataQuery model.CollectionListQueryRequest, dataParam model.CollectionListParamRequest) (*model.CollectionListResponse, error)
	CreateCollection(ctx context.Context, dataBody model.CollectionCreationBodyRequest, dataParam model.CollectionCreationParamRequest) (*model.CollectionCreationResponse, error)
	DeleteCollection(ctx context.Context, dataBody model.CollectionDeletionBodyRequest, dataParam model.CollectionDeletionParamRequest) (*model.CollectionDeletionResponse, error)
}

func (uc *controller) CreateCollection(ctx context.Context, dataBody model.CollectionCreationBodyRequest, dataParam model.CollectionCreationParamRequest) (*model.CollectionCreationResponse, error) {
	if _, err := uc.databaseRepo.GetDatabaseByID(ctx, dataParam.DatabaseID); err != nil {
		return nil, err
	}
	if _, err := uc.indexRepo.GetIndexByCollectionAndDatabaseID(ctx, dataBody.CollectionName, dataParam.DatabaseID); err == nil {
		return nil, err
	}
	if err := uc.indexRepo.CreateCollection(ctx, dataParam.DatabaseID, dataBody.CollectionName); err != nil {
		return nil, err
	}

	dataResponse := &model.CollectionCreationResponse{
		Status: true,
	}
	return dataResponse, nil
}

func (uc *controller) CreateDatabase(ctx context.Context, dataRequest model.DatabaseCreationRequest) (*model.DatabaseCreationResponse, error) {
	currentTime := time.Now()
	database := model.Database{
		Name:        dataRequest.Name,
		Description: dataRequest.Description,
		Uri:         dataRequest.Uri,
		DBName:      dataRequest.DBName,
		CreatedAt:   currentTime,
		UpdatedAt:   currentTime,
	}

	if dataRequest.TestConnection {
		if _, err := util.NewMongoDatabase(ctx, dataRequest.Uri, dataRequest.DBName); err != nil {
			return nil, err
		}
	}
	dataInserted, err := uc.databaseRepo.CreateDatabase(ctx, database)
	if err != nil {
		return nil, err
	}

	return &model.DatabaseCreationResponse{
		ID: dataInserted.ID.Hex(),
	}, nil
}

func (uc *controller) DeleteCollection(ctx context.Context, dataBody model.CollectionDeletionBodyRequest, dataParam model.CollectionDeletionParamRequest) (*model.CollectionDeletionResponse, error) {
	if _, err := uc.databaseRepo.GetDatabaseByID(ctx, dataParam.DatabaseID); err != nil {
		return nil, err
	}
	if _, err := uc.indexRepo.GetIndexByCollection(ctx, dataBody.CollectionName); err != nil {
		return nil, err
	}
	if err := uc.indexRepo.DeleteIndexesByCollection(ctx, dataBody.CollectionName); err != nil {
		return nil, err
	}

	return &model.CollectionDeletionResponse{
		Status: true,
	}, nil
}

func (uc *controller) DeleteDatabase(ctx context.Context, dataRequest model.DatabaseDeletionParamRequest) (*model.DatabaseDeletionResponse, error) {
	if _, err := uc.databaseRepo.GetDatabaseByID(ctx, dataRequest.ID); err != nil {
		return nil, err
	}
	if err := uc.databaseRepo.DeleteDatabaseByID(ctx, dataRequest.ID); err != nil {
		return nil, err
	}
	go func() {
		if err := uc.indexRepo.DeleteIndexesByDatabaseID(ctx, dataRequest.ID); err != nil {
			logger.Error().Err(err).Str("function", "DeleteDatabase").Str("functionInline", "uc.indexRepo.DeleteIndexesByDatabaseID").Msg("databaseUsecase")
		}
	}()

	return &model.DatabaseDeletionResponse{
		Status: true,
	}, nil
}

func (uc *controller) DeleteDatabases(ctx context.Context, dataRequest model.DatabaseManyDeletionRequest) (*model.DatabaseDeletionResponse, error) {
	if err := uc.databaseRepo.DeleteDatabasesByIDs(ctx, dataRequest.IDs); err != nil {
		return nil, err
	}
	go func() {
		if err := uc.indexRepo.DeleteIndexesByDatabaseIDs(ctx, dataRequest.IDs); err != nil {
			logger.Error().Err(err).Str("function", "DeleteDatabases").Str("functionInline", "uc.databaseRepo.DeleteDatabasesByIDs").Msg("databaseUsecase")
		}
	}()

	return &model.DatabaseDeletionResponse{
		Status: true,
	}, nil
}

func (uc *controller) GetAllDatabase(ctx context.Context, dataRequest model.DatabaseGetAllRequest) (*model.DatabaseGetAllResponse, error) {
	data, err := uc.databaseRepo.GetDatabases(ctx, &dataRequest.Paging, &dataRequest.Filter)
	if err != nil {
		return nil, err
	}
	if data == nil {
		data = []model.Database{}
	}

	dataResponse := &model.DatabaseGetAllResponse{
		Records: data,
		Paging:  &dataRequest.Paging,
	}
	return dataResponse, nil
}

func (uc *controller) GetOneDatabase(ctx context.Context, dataRequest model.DatabaseGetOneRequest) (*model.DatabaseGetOneResponse, error) {
	data, err := uc.databaseRepo.GetDatabaseByID(ctx, dataRequest.ID)
	if err != nil {
		return nil, err
	}

	return &model.DatabaseGetOneResponse{
		Name:        data.Name,
		Description: data.Description,
		Uri:         data.Uri,
		DBName:      data.DBName,
		CreatedAt:   data.CreatedAt,
		UpdatedAt:   data.UpdatedAt,
	}, nil
}

func (uc *controller) ListCollections(ctx context.Context, dataQuery model.CollectionListQueryRequest, dataParam model.CollectionListParamRequest) (*model.CollectionListResponse, error) {
	if _, err := uc.databaseRepo.GetDatabaseByID(ctx, dataParam.DatabaseID); err != nil {
		return nil, err
	}
	data, err := uc.indexRepo.ListCollections(ctx, dataParam.DatabaseID, &dataQuery.Paging, &dataQuery.Filter)
	if err != nil {
		return nil, err
	}

	if data == nil {
		data = []*model.CollectionResponse{}
	}
	return &model.CollectionListResponse{
		Records: data,
		Paging:  &dataQuery.Paging,
	}, nil
}

func (uc *controller) UpdateDatabase(ctx context.Context, dataBody model.DatabaseUpdateBodyRequest, dataParam model.DatabaseUpdateParamRequest) (*model.DatabaseUpdateResponse, error) {
	dataUpdate := model.Database{
		ID:          dataParam.ID,
		Name:        dataBody.Name,
		Description: dataBody.Description,
		Uri:         dataBody.Uri,
		DBName:      dataBody.DBName,
		UpdatedAt:   time.Now(),
	}
	if _, err := uc.databaseRepo.GetDatabaseByID(ctx, dataParam.ID); err != nil {
		return nil, err
	}
	if dataBody.TestConnection {
		if _, err := util.NewMongoDatabase(ctx, dataBody.Uri, dataBody.DBName); err != nil {
			return nil, err
		}
	}

	if err := uc.databaseRepo.UpdateDatabaseByID(ctx, dataUpdate.ID, dataUpdate); err != nil {
		return nil, err
	}

	return &model.DatabaseUpdateResponse{
		Status: true,
	}, nil
}
