package index

import (
	"context"
	"strings"
	"time"

	"training-doctor-manager/common"
	"training-doctor-manager/common/logging"
	DatabaseRepo "training-doctor-manager/pkg/database/repository"
	"training-doctor-manager/pkg/index/model"
	IndexRepo "training-doctor-manager/pkg/index/repository"
	syncingmodel "training-doctor-manager/pkg/syncing/model"
	SyncingRepo "training-doctor-manager/pkg/syncing/repository"
	"training-doctor-manager/util"
	"training-doctor-manager/util/asyncjob"
)

var (
	logger = logging.GetLogger()
)

type controller struct {
	indexRepo    IndexRepo.IndexRepository
	databaseRepo DatabaseRepo.DatabaseRepository
	syncingRepo  SyncingRepo.SyncingRepository
}

func New(indexRepository IndexRepo.IndexRepository, databaseRepo DatabaseRepo.DatabaseRepository, syncingRepo SyncingRepo.SyncingRepository) Controller {
	return &controller{
		indexRepo:    indexRepository,
		databaseRepo: databaseRepo,
		syncingRepo:  syncingRepo,
	}
}

type Controller interface {
	GetIndexes(ctx context.Context, dataRequest model.IndexGetAllRequest) (*model.IndexGetAllResponse, error)
	GetIndex(ctx context.Context, dataRequest model.IndexGetOneRequest) (*model.IndexResponse, error)
	CreateIndex(ctx context.Context, dataRequest model.IndexCreationRequest) (*model.IndexCreationResponse, error)
	UpdateIndex(ctx context.Context, dataRequest model.IndexUpdateBodyRequest, dataParam model.IndexUpdateParamRequest) (*model.IndexUpdateResponse, error)
	DeleteIndex(ctx context.Context, dataRequest model.IndexDeletionRequest) (*model.IndexDeletionResponse, error)
	DeleteIndexes(ctx context.Context, dataRequest model.IndexManyDeletionRequest) (*model.IndexDeletionResponse, error)
	SyncIndexesByCollection(ctx context.Context, dataRequest model.IndexSyncCollectionRequest) (*model.IndexSyncCollectionResponse, error)
	SyncIndexesByDatabase(ctx context.Context, dataRequest model.IndexSyncDatabaseRequest) (*model.IndexSyncDatabaseResponse, error)
	CompareIndexesByCollection(ctx context.Context, dataRequest model.IndexCompareCollectionRequest) (*model.IndexCompareCollectionResponse, error)
	CompareIndexesByDatabase(ctx context.Context, dataRequest model.IndexCompareDatabaseRequest) (*model.IndexCompareDatabaseResponse, error)
}

func (uc *controller) CompareIndexesByCollection(ctx context.Context, dataRequest model.IndexCompareCollectionRequest) (*model.IndexCompareCollectionResponse, error) {
	data, err := uc.databaseRepo.GetDatabaseByID(ctx, dataRequest.DatabaseID)
	if err != nil {
		return nil, err
	}
	dbClient, err := util.NewMongoDatabase(ctx, data.Uri, data.DBName)
	if err != nil {
		return nil, err
	}
	indexesAdmin, err := uc.indexRepo.GetIndexesByDatabaseIDAndCollection(ctx, dataRequest.DatabaseID, dataRequest.CollectionName)
	if err != nil {
		return nil, err
	}
	indexesClient, err := uc.indexRepo.GetIndexesFromClient(ctx, dbClient, dataRequest.CollectionName)
	if err != nil {
		return nil, err
	}

	response := model.IndexCompareCollectionResponse{
		MissingIndexes: make([]model.IndexCompare, 0),
		MatchedIndexes: make([]model.IndexCompare, 0),
		ExtraIndexes:   make([]model.IndexCompare, 0),
	}
	mapIndexesAdmin := make(map[string]model.IndexCompare)
	for _, index := range indexesAdmin {
		key := index.ToKeyString()
		mapIndexesAdmin[key] = model.ToIndexCompareResponse(index)
	}
	mapIndexesClient := make(map[string]model.IndexCompare)
	for _, index := range indexesClient {
		if index.Name != "_id_" {
			key := index.ToKeyString()
			mapIndexesClient[key] = model.ToIndexCompareResponse(index)
		}
	}
	for keyOptionString, index := range mapIndexesAdmin {
		if _, ok := mapIndexesClient[keyOptionString]; !ok {
			response.MissingIndexes = append(response.MissingIndexes, index)
		} else {
			response.MatchedIndexes = append(response.MatchedIndexes, index)
		}
		delete(mapIndexesClient, keyOptionString)
	}

	for _, index := range mapIndexesClient {
		response.ExtraIndexes = append(response.ExtraIndexes, index)
	}
	return &response, nil
}

func (uc *controller) CompareIndexesByDatabase(ctx context.Context, dataRequest model.IndexCompareDatabaseRequest) (*model.IndexCompareDatabaseResponse, error) {
	data, err := uc.databaseRepo.GetDatabaseByID(ctx, dataRequest.DatabaseID)
	if err != nil {
		return nil, err
	}
	dbClient, err := util.NewMongoDatabase(ctx, data.Uri, data.DBName)
	if err != nil {
		return nil, err
	}
	collections, err := uc.indexRepo.GetCollectionsByDatabaseID(ctx, dataRequest.DatabaseID)
	if err != nil {
		return nil, err
	}

	response := model.IndexCompareDatabaseResponse{Result: make([]model.IndexCompareDatabaseElement, 0)}
	for _, coll := range collections {
		indexesAdmin, err := uc.indexRepo.GetIndexesByDatabaseIDAndCollection(ctx, dataRequest.DatabaseID, coll.CollectionName)
		if err != nil {
			return nil, err
		}
		indexesClient, err := uc.indexRepo.GetIndexesFromClient(ctx, dbClient, coll.CollectionName)
		if err != nil {
			return nil, err
		}
		respElement := model.IndexCompareDatabaseElement{
			CollectionName: coll.CollectionName,
			MissingIndexes: make([]model.IndexCompare, 0),
			MatchedIndexes: make([]model.IndexCompare, 0),
			ExtraIndexes:   make([]model.IndexCompare, 0),
		}
		mapIndexesAdmin := make(map[string]model.IndexCompare)
		for _, index := range indexesAdmin {
			key := index.ToKeyString()
			mapIndexesAdmin[key] = model.ToIndexCompareResponse(index)
		}
		mapIndexesClient := make(map[string]model.IndexCompare)
		for _, index := range indexesClient {
			if index.Name != "_id_" {
				key := index.ToKeyString()
				mapIndexesClient[key] = model.ToIndexCompareResponse(index)
			}
		}
		for keyOptionString, index := range mapIndexesAdmin {
			if _, ok := mapIndexesClient[keyOptionString]; !ok {
				respElement.MissingIndexes = append(respElement.MissingIndexes, index)
			} else {
				respElement.MatchedIndexes = append(respElement.MatchedIndexes, index)
			}

			delete(mapIndexesClient, keyOptionString)
		}

		for _, index := range mapIndexesClient {
			respElement.ExtraIndexes = append(respElement.ExtraIndexes, index)
		}
		response.Result = append(response.Result, respElement)
	}
	return &response, nil
}

func (uc *controller) CreateIndex(ctx context.Context, dataRequest model.IndexCreationRequest) (*model.IndexCreationResponse, error) {
	if _, err := uc.databaseRepo.GetDatabaseByID(ctx, dataRequest.DatabaseID); err != nil {
		return nil, err
	}

	currentTime := time.Now()
	indexKeysModel := model.ToIndexKeyModelArr(dataRequest.Keys)
	indexModel := model.Index{
		DatabaseID: dataRequest.DatabaseID,
		Collection: dataRequest.Collection,
		Name:       dataRequest.Name,
		Keys:       indexKeysModel,
		Options: model.IndexOption{
			IsUnique:           dataRequest.Options.IsUnique,
			ExpireAfterSeconds: dataRequest.Options.ExpireAfterSeconds,
		},
		CreatedAt: currentTime,
		UpdatedAt: currentTime,
	}
	indexModel.KeyString = indexModel.ToKeyString()
	if strings.TrimSpace(indexModel.Name) == "" {
		indexModel.Name = model.ToNameFromKeys(indexModel.Keys)
	}

	dataInserted, err := uc.indexRepo.CreateIndex(ctx, indexModel)
	if err != nil {
		return nil, err
	}
	return &model.IndexCreationResponse{
		ID: dataInserted.ID.Hex(),
	}, nil
}

func (uc *controller) DeleteIndex(ctx context.Context, dataRequest model.IndexDeletionRequest) (*model.IndexDeletionResponse, error) {
	if _, err := uc.indexRepo.GetIndexByID(ctx, dataRequest.ID); err != nil {
		return nil, err
	}

	if err := uc.indexRepo.DeleteIndexByID(ctx, dataRequest.ID); err != nil {
		return nil, err
	}

	dataResponse := &model.IndexDeletionResponse{
		Status: true,
	}
	return dataResponse, nil
}

func (uc *controller) DeleteIndexes(ctx context.Context, dataRequest model.IndexManyDeletionRequest) (*model.IndexDeletionResponse, error) {
	if err := uc.indexRepo.DeleteIndexesByIDs(ctx, dataRequest.IDs); err != nil {
		return nil, err
	}

	return &model.IndexDeletionResponse{
		Status: true,
	}, nil
}

func (uc *controller) GetIndex(ctx context.Context, dataRequest model.IndexGetOneRequest) (*model.IndexResponse, error) {
	data, err := uc.indexRepo.GetIndexByID(ctx, dataRequest.IndexID)
	if err != nil {
		return nil, err
	}

	return &model.IndexResponse{
		ID:         data.ID,
		DatabaseID: data.DatabaseID,
		Collection: data.Collection,
		Name:       data.Name,
		Keys:       model.ToIndexKeyResponseArr(data.Keys),
		Options: model.IndexOptionResponse{
			IsUnique:           data.Options.IsUnique,
			ExpireAfterSeconds: data.Options.ExpireAfterSeconds,
		},
		CreatedAt: data.CreatedAt,
		UpdatedAt: data.UpdatedAt,
	}, nil
}

func (uc *controller) GetIndexes(ctx context.Context, dataRequest model.IndexGetAllRequest) (*model.IndexGetAllResponse, error) {
	if _, err := uc.databaseRepo.GetDatabaseByID(ctx, dataRequest.DatabaseID); err != nil {
		return nil, err
	}
	data, err := uc.indexRepo.GetIndexesByDatabaseIDAndCollection(ctx, dataRequest.DatabaseID, dataRequest.CollectionName)
	if err != nil {
		return nil, err
	}

	indexes := make([]model.IndexResponse, len(data))
	for id, value := range data {
		indexes[id] = model.IndexResponse{
			ID:         value.ID,
			DatabaseID: value.DatabaseID,
			Collection: value.Collection,
			Name:       value.Name,
			Keys:       model.ToIndexKeyResponseArr(value.Keys),
			Options: model.IndexOptionResponse{
				IsUnique:           value.Options.IsUnique,
				ExpireAfterSeconds: value.Options.ExpireAfterSeconds,
			},
			CreatedAt: value.CreatedAt,
			UpdatedAt: value.UpdatedAt,
		}
	}
	return &model.IndexGetAllResponse{Data: indexes}, nil
}

func (uc *controller) SyncIndexesByCollection(ctx context.Context, dataRequest model.IndexSyncCollectionRequest) (*model.IndexSyncCollectionResponse, error) {
	data, err := uc.databaseRepo.GetDatabaseByID(ctx, dataRequest.DatabaseID)
	if err != nil {
		return nil, err
	}
	dbClient, err := util.NewMongoDatabase(ctx, data.Uri, data.DBName)
	if err != nil {
		return nil, err
	}
	dataIndexes, err := uc.CompareIndexesByCollection(ctx, model.IndexCompareCollectionRequest{
		DatabaseID:     dataRequest.DatabaseID,
		CollectionName: dataRequest.CollectionName,
	})
	if err != nil {
		return nil, err
	}

	if err = uc.indexRepo.SyncIndexesByCollection(ctx, dbClient,
		dataRequest.DatabaseID, dataRequest.CollectionName,
		dataIndexes.MissingIndexes, dataIndexes.ExtraIndexes,
		dataRequest.OptionMissing, dataRequest.OptionExtra,
	); err != nil {
		return nil, err
	}

	syncInserted, err := uc.syncingRepo.CreateSyncing(ctx, syncingmodel.Syncing{
		UserID:         dataRequest.UserID,
		DatabaseID:     dataRequest.DatabaseID,
		CollectionName: dataRequest.CollectionName,
		Type:           common.TypeSyncCollection,
		TotalTasks:     1,
		CompletedTasks: 0,
	})
	if err != nil {
		return nil, err
	}

	job := asyncjob.NewJob(func(ctx context.Context) error {
		if err = uc.indexRepo.SyncIndexesByCollection(ctx, dbClient,
			dataRequest.DatabaseID, dataRequest.CollectionName,
			dataIndexes.MissingIndexes, dataIndexes.ExtraIndexes,
			dataRequest.OptionMissing, dataRequest.OptionExtra,
		); err != nil {
			_ = uc.syncingRepo.UpdateErrorByID(ctx, syncInserted.ID, err.Error())
			return err
		}

		_ = uc.syncingRepo.UpdateIncreaseCompletedTaskByID(ctx, syncInserted.ID, 1)
		return nil
	}, asyncjob.WithName("job SyncIndexesByCollection | "+dataRequest.CollectionName))

	go func() {
		if err = asyncjob.NewGroup(true, job).Run(ctx); err != nil {
			logger.Error().Err(err).Str("function", "SyncIndexesByCollection").Str("functionInline", "asyncjob.NewGroup(true, job).Run").Msg("indexUsecase")
		}
	}()

	return &model.IndexSyncCollectionResponse{Status: true}, nil
}

func (uc *controller) SyncIndexesByDatabase(ctx context.Context, dataRequest model.IndexSyncDatabaseRequest) (*model.IndexSyncDatabaseResponse, error) {
	data, err := uc.databaseRepo.GetDatabaseByID(ctx, dataRequest.DatabaseID)
	if err != nil {
		return nil, err
	}

	dbClient, err := util.NewMongoDatabase(ctx, data.Uri, data.DBName)
	if err != nil {
		return nil, err
	}

	indexCompareData, err := uc.CompareIndexesByDatabase(ctx, model.IndexCompareDatabaseRequest{
		DatabaseID: dataRequest.DatabaseID,
	})
	if err != nil {
		return nil, err
	}

	syncInserted, err := uc.syncingRepo.CreateSyncing(ctx, syncingmodel.Syncing{
		UserID:         dataRequest.UserID,
		DatabaseID:     dataRequest.DatabaseID,
		TotalTasks:     len(indexCompareData.Result),
		CompletedTasks: 0,
		Type:           common.TypeSyncDatabase,
	})
	if err != nil {
		return nil, err
	}

	jobs := make([]asyncjob.Job, 0)
	for _, dataCompare := range indexCompareData.Result {
		job := asyncjob.NewJob(func(ctx context.Context) error {
			if err = uc.indexRepo.SyncIndexesByCollection(ctx, dbClient,
				dataRequest.DatabaseID, dataCompare.CollectionName,
				dataCompare.MissingIndexes, dataCompare.ExtraIndexes,
				dataRequest.OptionMissing, dataRequest.OptionExtra,
			); err != nil {
				_ = uc.syncingRepo.UpdateErrorByID(ctx, syncInserted.ID, "error at collection "+dataCompare.CollectionName+":"+err.Error())
				return err
			}

			_ = uc.syncingRepo.UpdateIncreaseCompletedTaskByID(ctx, syncInserted.ID, 1)
			return nil
		}, asyncjob.WithName("job SyncIndexesByCollection | "+dataCompare.CollectionName))

		jobs = append(jobs, job)
	}

	go func() {
		if err = asyncjob.NewGroup(true, jobs...).Run(ctx); err != nil {
			logger.Error().Err(err).Str("function", "SyncIndexesByDatabase").Str("functionInline", "asyncjob.NewGroup").Msg("indexUsecase")
		}
	}()

	return &model.IndexSyncDatabaseResponse{Status: true}, nil
}

func (uc *controller) UpdateIndex(ctx context.Context, dataRequest model.IndexUpdateBodyRequest, dataParam model.IndexUpdateParamRequest) (*model.IndexUpdateResponse, error) {
	indexModel, err := uc.indexRepo.GetIndexByID(ctx, dataParam.ID)
	if err != nil {
		return nil, err
	}

	currentTime := time.Now()
	indexKeysModel := model.ToIndexKeyModelArr(dataRequest.Keys)
	dataUpdate := model.Index{
		ID:         dataParam.ID,
		DatabaseID: indexModel.DatabaseID,
		Collection: indexModel.Collection,
		Name:       dataRequest.Name,
		Keys:       indexKeysModel,
		Options: model.IndexOption{
			IsUnique:           dataRequest.Options.IsUnique,
			ExpireAfterSeconds: dataRequest.Options.ExpireAfterSeconds,
		},
		CreatedAt: indexModel.CreatedAt,
		UpdatedAt: currentTime,
	}
	dataUpdate.KeyString = dataUpdate.ToKeyString()
	if strings.TrimSpace(dataUpdate.Name) == "" {
		dataUpdate.Name = model.ToNameFromKeys(indexModel.Keys)
	}

	if err = uc.indexRepo.UpdateIndexByID(ctx, dataParam.ID, dataUpdate); err != nil {
		return nil, err
	}

	dataResponse := &model.IndexUpdateResponse{
		Status: true,
	}
	return dataResponse, nil
}
