package index

import (
	"context"
	"strings"
	"time"

	"training-doctor-manager/common/constant"
	"training-doctor-manager/common/logging"
	"training-doctor-manager/pkg/models"
	"training-doctor-manager/pkg/parameters"
	"training-doctor-manager/pkg/repository"
	"training-doctor-manager/util"
	"training-doctor-manager/util/asyncjob"
)

var (
	logger = logging.GetLogger()
)

type controller struct {
	indexRepo    repository.IndexRepository
	databaseRepo repository.DatabaseRepository
	syncingRepo  repository.SyncingRepository
}

func New(indexRepository repository.IndexRepository, databaseRepo repository.DatabaseRepository, syncingRepo repository.SyncingRepository) Controller {
	return &controller{
		indexRepo:    indexRepository,
		databaseRepo: databaseRepo,
		syncingRepo:  syncingRepo,
	}
}

type Controller interface {
	GetIndexes(ctx context.Context, dataRequest models.IndexGetAllRequest) (*models.IndexGetAllResponse, error)
	GetIndex(ctx context.Context, dataRequest models.IndexGetOneRequest) (*models.IndexResponse, error)
	CreateIndex(ctx context.Context, dataRequest models.IndexCreationRequest) (*models.IndexCreationResponse, error)
	UpdateIndex(ctx context.Context, dataRequest models.IndexUpdateBodyRequest, dataParam models.IndexUpdateParamRequest) (*models.IndexUpdateResponse, error)
	DeleteIndex(ctx context.Context, dataRequest models.IndexDeletionRequest) (*models.IndexDeletionResponse, error)
	DeleteIndexes(ctx context.Context, dataRequest models.IndexManyDeletionRequest) (*models.IndexDeletionResponse, error)
	SyncIndexesByCollection(ctx context.Context, dataRequest models.IndexSyncCollectionRequest) (*models.IndexSyncCollectionResponse, error)
	SyncIndexesByDatabase(ctx context.Context, dataRequest models.IndexSyncDatabaseRequest) (*models.IndexSyncDatabaseResponse, error)
	CompareIndexesByCollection(ctx context.Context, dataRequest models.IndexCompareCollectionRequest) (*models.IndexCompareCollectionResponse, error)
	CompareIndexesByDatabase(ctx context.Context, dataRequest models.IndexCompareDatabaseRequest) (*models.IndexCompareDatabaseResponse, error)
}

func (uc *controller) CompareIndexesByCollection(ctx context.Context, dataRequest models.IndexCompareCollectionRequest) (*models.IndexCompareCollectionResponse, error) {
	data, err := uc.databaseRepo.GetDatabaseByID(ctx, dataRequest.DatabaseID)
	if err != nil {
		return nil, err
	}
	dbClient, err := util.NewMongoDatabase(ctx, data.Uri, data.DBName)
	if err != nil {
		return nil, err
	}
	indexesAdmin, err := uc.indexRepo.GetIndexesByDatabaseIDAndCollection(ctx, dataRequest.DatabaseID, dataRequest.CollectionName)
	if err != nil {
		return nil, err
	}
	indexesClient, err := uc.indexRepo.GetIndexesFromClient(ctx, dbClient, dataRequest.CollectionName)
	if err != nil {
		return nil, err
	}

	response := models.IndexCompareCollectionResponse{
		MissingIndexes: make([]models.IndexCompare, 0),
		MatchedIndexes: make([]models.IndexCompare, 0),
		ExtraIndexes:   make([]models.IndexCompare, 0),
	}
	mapIndexesAdmin := make(map[string]models.IndexCompare)
	for _, index := range indexesAdmin {
		key := index.ToKeyString()
		mapIndexesAdmin[key] = parameters.ToIndexCompareResponse(index)
	}
	mapIndexesClient := make(map[string]models.IndexCompare)
	for _, index := range indexesClient {
		if index.Name != "_id_" {
			key := index.ToKeyString()
			mapIndexesClient[key] = parameters.ToIndexCompareResponse(index)
		}
	}
	for keyOptionString, index := range mapIndexesAdmin {
		if _, ok := mapIndexesClient[keyOptionString]; !ok {
			response.MissingIndexes = append(response.MissingIndexes, index)
		} else {
			response.MatchedIndexes = append(response.MatchedIndexes, index)
		}
		delete(mapIndexesClient, keyOptionString)
	}

	for _, index := range mapIndexesClient {
		response.ExtraIndexes = append(response.ExtraIndexes, index)
	}
	return &response, nil
}

func (uc *controller) CompareIndexesByDatabase(ctx context.Context, dataRequest models.IndexCompareDatabaseRequest) (*models.IndexCompareDatabaseResponse, error) {
	data, err := uc.databaseRepo.GetDatabaseByID(ctx, dataRequest.DatabaseID)
	if err != nil {
		return nil, err
	}
	dbClient, err := util.NewMongoDatabase(ctx, data.Uri, data.DBName)
	if err != nil {
		return nil, err
	}
	collections, err := uc.indexRepo.GetCollectionsByDatabaseID(ctx, dataRequest.DatabaseID)
	if err != nil {
		return nil, err
	}

	response := models.IndexCompareDatabaseResponse{Result: make([]models.IndexCompareDatabaseElement, 0)}
	for _, coll := range collections {
		indexesAdmin, err := uc.indexRepo.GetIndexesByDatabaseIDAndCollection(ctx, dataRequest.DatabaseID, coll.CollectionName)
		if err != nil {
			return nil, err
		}
		indexesClient, err := uc.indexRepo.GetIndexesFromClient(ctx, dbClient, coll.CollectionName)
		if err != nil {
			return nil, err
		}
		respElement := models.IndexCompareDatabaseElement{
			CollectionName: coll.CollectionName,
			MissingIndexes: make([]models.IndexCompare, 0),
			MatchedIndexes: make([]models.IndexCompare, 0),
			ExtraIndexes:   make([]models.IndexCompare, 0),
		}
		mapIndexesAdmin := make(map[string]models.IndexCompare)
		for _, index := range indexesAdmin {
			key := index.ToKeyString()
			mapIndexesAdmin[key] = parameters.ToIndexCompareResponse(index)
		}
		mapIndexesClient := make(map[string]models.IndexCompare)
		for _, index := range indexesClient {
			if index.Name != "_id_" {
				key := index.ToKeyString()
				mapIndexesClient[key] = parameters.ToIndexCompareResponse(index)
			}
		}
		for keyOptionString, index := range mapIndexesAdmin {
			if _, ok := mapIndexesClient[keyOptionString]; !ok {
				respElement.MissingIndexes = append(respElement.MissingIndexes, index)
			} else {
				respElement.MatchedIndexes = append(respElement.MatchedIndexes, index)
			}

			delete(mapIndexesClient, keyOptionString)
		}

		for _, index := range mapIndexesClient {
			respElement.ExtraIndexes = append(respElement.ExtraIndexes, index)
		}
		response.Result = append(response.Result, respElement)
	}
	return &response, nil
}

func (uc *controller) CreateIndex(ctx context.Context, dataRequest models.IndexCreationRequest) (*models.IndexCreationResponse, error) {
	if _, err := uc.databaseRepo.GetDatabaseByID(ctx, dataRequest.DatabaseID); err != nil {
		return nil, err
	}

	currentTime := time.Now()
	indexKeysModel := parameters.ToIndexKeyModelArr(dataRequest.Keys)
	indexModel := models.Index{
		DatabaseID: dataRequest.DatabaseID,
		Collection: dataRequest.Collection,
		Name:       dataRequest.Name,
		Keys:       indexKeysModel,
		Options: models.IndexOption{
			IsUnique:           dataRequest.Options.IsUnique,
			ExpireAfterSeconds: dataRequest.Options.ExpireAfterSeconds,
		},
		CreatedAt: currentTime,
		UpdatedAt: currentTime,
	}
	indexModel.KeyString = indexModel.ToKeyString()
	if strings.TrimSpace(indexModel.Name) == "" {
		indexModel.Name = parameters.ToNameFromKeys(indexModel.Keys)
	}

	dataInserted, err := uc.indexRepo.CreateIndex(ctx, indexModel)
	if err != nil {
		return nil, err
	}
	return &models.IndexCreationResponse{
		ID: dataInserted.ID.Hex(),
	}, nil
}

func (uc *controller) DeleteIndex(ctx context.Context, dataRequest models.IndexDeletionRequest) (*models.IndexDeletionResponse, error) {
	if _, err := uc.indexRepo.GetIndexByID(ctx, dataRequest.ID); err != nil {
		return nil, err
	}

	if err := uc.indexRepo.DeleteIndexByID(ctx, dataRequest.ID); err != nil {
		return nil, err
	}

	dataResponse := &models.IndexDeletionResponse{
		Status: true,
	}
	return dataResponse, nil
}

func (uc *controller) DeleteIndexes(ctx context.Context, dataRequest models.IndexManyDeletionRequest) (*models.IndexDeletionResponse, error) {
	if err := uc.indexRepo.DeleteIndexesByIDs(ctx, dataRequest.IDs); err != nil {
		return nil, err
	}

	return &models.IndexDeletionResponse{
		Status: true,
	}, nil
}

func (uc *controller) GetIndex(ctx context.Context, dataRequest models.IndexGetOneRequest) (*models.IndexResponse, error) {
	data, err := uc.indexRepo.GetIndexByID(ctx, dataRequest.IndexID)
	if err != nil {
		return nil, err
	}

	return &models.IndexResponse{
		ID:         data.ID,
		DatabaseID: data.DatabaseID,
		Collection: data.Collection,
		Name:       data.Name,
		Keys:       parameters.ToIndexKeyResponseArr(data.Keys),
		Options: models.IndexOptionResponse{
			IsUnique:           data.Options.IsUnique,
			ExpireAfterSeconds: data.Options.ExpireAfterSeconds,
		},
		CreatedAt: data.CreatedAt,
		UpdatedAt: data.UpdatedAt,
	}, nil
}

func (uc *controller) GetIndexes(ctx context.Context, dataRequest models.IndexGetAllRequest) (*models.IndexGetAllResponse, error) {
	if _, err := uc.databaseRepo.GetDatabaseByID(ctx, dataRequest.DatabaseID); err != nil {
		return nil, err
	}
	data, err := uc.indexRepo.GetIndexesByDatabaseIDAndCollection(ctx, dataRequest.DatabaseID, dataRequest.CollectionName)
	if err != nil {
		return nil, err
	}

	indexes := make([]models.IndexResponse, len(data))
	for id, value := range data {
		indexes[id] = models.IndexResponse{
			ID:         value.ID,
			DatabaseID: value.DatabaseID,
			Collection: value.Collection,
			Name:       value.Name,
			Keys:       parameters.ToIndexKeyResponseArr(value.Keys),
			Options: models.IndexOptionResponse{
				IsUnique:           value.Options.IsUnique,
				ExpireAfterSeconds: value.Options.ExpireAfterSeconds,
			},
			CreatedAt: value.CreatedAt,
			UpdatedAt: value.UpdatedAt,
		}
	}
	return &models.IndexGetAllResponse{Data: indexes}, nil
}

func (uc *controller) SyncIndexesByCollection(ctx context.Context, dataRequest models.IndexSyncCollectionRequest) (*models.IndexSyncCollectionResponse, error) {
	data, err := uc.databaseRepo.GetDatabaseByID(ctx, dataRequest.DatabaseID)
	if err != nil {
		return nil, err
	}
	dbClient, err := util.NewMongoDatabase(ctx, data.Uri, data.DBName)
	if err != nil {
		return nil, err
	}
	dataIndexes, err := uc.CompareIndexesByCollection(ctx, models.IndexCompareCollectionRequest{
		DatabaseID:     dataRequest.DatabaseID,
		CollectionName: dataRequest.CollectionName,
	})
	if err != nil {
		return nil, err
	}

	if err = uc.indexRepo.SyncIndexesByCollection(ctx, dbClient,
		dataRequest.DatabaseID, dataRequest.CollectionName,
		dataIndexes.MissingIndexes, dataIndexes.ExtraIndexes,
		dataRequest.OptionMissing, dataRequest.OptionExtra,
	); err != nil {
		return nil, err
	}

	syncInserted, err := uc.syncingRepo.CreateSyncing(ctx, models.Syncing{
		UserID:         dataRequest.UserID,
		DatabaseID:     dataRequest.DatabaseID,
		CollectionName: dataRequest.CollectionName,
		Type:           constant.TypeSyncCollection,
		TotalTasks:     1,
		CompletedTasks: 0,
	})
	if err != nil {
		return nil, err
	}

	job := asyncjob.NewJob(func(ctx context.Context) error {
		if err = uc.indexRepo.SyncIndexesByCollection(ctx, dbClient,
			dataRequest.DatabaseID, dataRequest.CollectionName,
			dataIndexes.MissingIndexes, dataIndexes.ExtraIndexes,
			dataRequest.OptionMissing, dataRequest.OptionExtra,
		); err != nil {
			_ = uc.syncingRepo.UpdateErrorByID(ctx, syncInserted.ID, err.Error())
			return err
		}

		_ = uc.syncingRepo.UpdateIncreaseCompletedTaskByID(ctx, syncInserted.ID, 1)
		return nil
	}, asyncjob.WithName("job SyncIndexesByCollection | "+dataRequest.CollectionName))

	go func() {
		if err = asyncjob.NewGroup(true, job).Run(ctx); err != nil {
			logger.Error().Err(err).Str("function", "SyncIndexesByCollection").Str("functionInline", "asyncjob.NewGroup(true, job).Run").Msg("indexUsecase")
		}
	}()

	return &models.IndexSyncCollectionResponse{Status: true}, nil
}

func (uc *controller) SyncIndexesByDatabase(ctx context.Context, dataRequest models.IndexSyncDatabaseRequest) (*models.IndexSyncDatabaseResponse, error) {
	data, err := uc.databaseRepo.GetDatabaseByID(ctx, dataRequest.DatabaseID)
	if err != nil {
		return nil, err
	}

	dbClient, err := util.NewMongoDatabase(ctx, data.Uri, data.DBName)
	if err != nil {
		return nil, err
	}

	indexCompareData, err := uc.CompareIndexesByDatabase(ctx, models.IndexCompareDatabaseRequest{
		DatabaseID: dataRequest.DatabaseID,
	})
	if err != nil {
		return nil, err
	}

	syncInserted, err := uc.syncingRepo.CreateSyncing(ctx, models.Syncing{
		UserID:         dataRequest.UserID,
		DatabaseID:     dataRequest.DatabaseID,
		TotalTasks:     len(indexCompareData.Result),
		CompletedTasks: 0,
		Type:           constant.TypeSyncDatabase,
	})
	if err != nil {
		return nil, err
	}

	jobs := make([]asyncjob.Job, 0)
	for _, dataCompare := range indexCompareData.Result {
		job := asyncjob.NewJob(func(ctx context.Context) error {
			if err = uc.indexRepo.SyncIndexesByCollection(ctx, dbClient,
				dataRequest.DatabaseID, dataCompare.CollectionName,
				dataCompare.MissingIndexes, dataCompare.ExtraIndexes,
				dataRequest.OptionMissing, dataRequest.OptionExtra,
			); err != nil {
				_ = uc.syncingRepo.UpdateErrorByID(ctx, syncInserted.ID, "error at collection "+dataCompare.CollectionName+":"+err.Error())
				return err
			}

			_ = uc.syncingRepo.UpdateIncreaseCompletedTaskByID(ctx, syncInserted.ID, 1)
			return nil
		}, asyncjob.WithName("job SyncIndexesByCollection | "+dataCompare.CollectionName))

		jobs = append(jobs, job)
	}

	go func() {
		if err = asyncjob.NewGroup(true, jobs...).Run(ctx); err != nil {
			logger.Error().Err(err).Str("function", "SyncIndexesByDatabase").Str("functionInline", "asyncjob.NewGroup").Msg("indexUsecase")
		}
	}()

	return &models.IndexSyncDatabaseResponse{Status: true}, nil
}

func (uc *controller) UpdateIndex(ctx context.Context, dataRequest models.IndexUpdateBodyRequest, dataParam models.IndexUpdateParamRequest) (*models.IndexUpdateResponse, error) {
	indexModel, err := uc.indexRepo.GetIndexByID(ctx, dataParam.ID)
	if err != nil {
		return nil, err
	}

	currentTime := time.Now()
	indexKeysModel := parameters.ToIndexKeyModelArr(dataRequest.Keys)
	dataUpdate := models.Index{
		ID:         dataParam.ID,
		DatabaseID: indexModel.DatabaseID,
		Collection: indexModel.Collection,
		Name:       dataRequest.Name,
		Keys:       indexKeysModel,
		Options: models.IndexOption{
			IsUnique:           dataRequest.Options.IsUnique,
			ExpireAfterSeconds: dataRequest.Options.ExpireAfterSeconds,
		},
		CreatedAt: indexModel.CreatedAt,
		UpdatedAt: currentTime,
	}
	dataUpdate.KeyString = dataUpdate.ToKeyString()
	if strings.TrimSpace(dataUpdate.Name) == "" {
		dataUpdate.Name = parameters.ToNameFromKeys(indexModel.Keys)
	}

	if err = uc.indexRepo.UpdateIndexByID(ctx, dataParam.ID, dataUpdate); err != nil {
		return nil, err
	}

	dataResponse := &models.IndexUpdateResponse{
		Status: true,
	}
	return dataResponse, nil
}
