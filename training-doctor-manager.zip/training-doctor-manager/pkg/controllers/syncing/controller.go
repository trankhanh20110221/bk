package syncing

import (
	"context"

	"training-doctor-manager/pkg/models"
	"training-doctor-manager/pkg/repository"
)

type controller struct {
	syncingRepo  repository.SyncingRepository
	databaseRepo repository.DatabaseRepository
}

func New(syncingRepository repository.SyncingRepository, databaseRepo repository.DatabaseRepository) Controller {
	return &controller{
		syncingRepo:  syncingRepository,
		databaseRepo: databaseRepo,
	}
}

type Controller interface {
	GetAllSyncing(ctx context.Context) (*models.SyncingGetAllResponse, error)
	DeleteSyncing(ctx context.Context, dataRequest models.SyncingDeletionRequest) (*models.SyncingDeletionResponse, error)
}

func (uc *controller) GetAllSyncing(ctx context.Context) (*models.SyncingGetAllResponse, error) {
	data, err := uc.syncingRepo.GetSyncing(ctx)
	if err != nil {
		return nil, err
	}

	syncingList := make([]models.SyncingResponse, len(data))
	for id, value := range data {
		db, err := uc.databaseRepo.GetDatabaseByID(ctx, value.DatabaseID)
		if err != nil {
			continue
		}

		syncingList[id] = models.SyncingResponse{
			ID:             value.ID,
			DatabaseID:     value.DatabaseID,
			CollectionName: value.CollectionName,
			DatabaseName:   db.DBName,
			Type:           value.Type,
			Error:          value.Error,
			TotalTasks:     value.TotalTasks,
			CompletedTasks: value.CompletedTasks,
			CreatedAt:      value.CreatedAt,
			UpdatedAt:      value.UpdatedAt,
		}
	}
	dataResponse := models.SyncingGetAllResponse{Data: syncingList}

	return &dataResponse, nil
}

func (uc *controller) DeleteSyncing(ctx context.Context, dataRequest models.SyncingDeletionRequest) (*models.SyncingDeletionResponse, error) {
	if err := uc.syncingRepo.DeleteSyncingByID(ctx, dataRequest.ID); err != nil {
		return nil, err
	}

	dataResponse := models.SyncingDeletionResponse{ID: dataRequest.ID}
	return &dataResponse, nil
}
