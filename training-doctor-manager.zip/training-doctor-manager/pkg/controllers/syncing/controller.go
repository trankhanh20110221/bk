package syncing

import (
	"context"

	DatabaseRepo "training-doctor-manager/pkg/database/repository"
	"training-doctor-manager/pkg/syncing/model"
	SyncingRepo "training-doctor-manager/pkg/syncing/repository"
)

type controller struct {
	syncingRepo  SyncingRepo.SyncingRepository
	databaseRepo DatabaseRepo.DatabaseRepository
}

func New(syncingRepository SyncingRepo.SyncingRepository, databaseRepo DatabaseRepo.DatabaseRepository) Controller {
	return &controller{
		syncingRepo:  syncingRepository,
		databaseRepo: databaseRepo,
	}
}

type Controller interface {
	GetAllSyncing(ctx context.Context) (*model.SyncingGetAllResponse, error)
	DeleteSyncing(ctx context.Context, dataRequest model.SyncingDeletionRequest) (*model.SyncingDeletionResponse, error)
}

func (uc *controller) GetAllSyncing(ctx context.Context) (*model.SyncingGetAllResponse, error) {
	data, err := uc.syncingRepo.GetSyncing(ctx)
	if err != nil {
		return nil, err
	}

	syncingList := make([]model.SyncingResponse, len(data))
	for id, value := range data {
		db, err := uc.databaseRepo.GetDatabaseByID(ctx, value.DatabaseID)
		if err != nil {
			continue
		}

		syncingList[id] = model.SyncingResponse{
			ID:             value.ID,
			DatabaseID:     value.DatabaseID,
			CollectionName: value.CollectionName,
			DatabaseName:   db.DBName,
			Type:           value.Type,
			Error:          value.Error,
			TotalTasks:     value.TotalTasks,
			CompletedTasks: value.CompletedTasks,
			CreatedAt:      value.CreatedAt,
			UpdatedAt:      value.UpdatedAt,
		}
	}
	dataResponse := model.SyncingGetAllResponse{Data: syncingList}

	return &dataResponse, nil
}

func (uc *controller) DeleteSyncing(ctx context.Context, dataRequest model.SyncingDeletionRequest) (*model.SyncingDeletionResponse, error) {
	if err := uc.syncingRepo.DeleteSyncingByID(ctx, dataRequest.ID); err != nil {
		return nil, err
	}

	dataResponse := model.SyncingDeletionResponse{ID: dataRequest.ID}
	return &dataResponse, nil
}
