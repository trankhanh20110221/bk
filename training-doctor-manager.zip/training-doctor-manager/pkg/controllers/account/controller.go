package account

import (
	"context"
	"net/http"
	"time"

	gojwt "github.com/golang-jwt/jwt/v5"
	"golang.org/x/crypto/bcrypt"
	"training-doctor-manager/common/config"
	"training-doctor-manager/common/constant"
	"training-doctor-manager/common/response"
	"training-doctor-manager/pkg/models"
	"training-doctor-manager/pkg/parameters"
	"training-doctor-manager/pkg/repository"
	"training-doctor-manager/provider/jwt"
)

type controller struct {
	accountRepo repository.AccountRepository
	tokenRepo   repository.AuthTokenRepository
	cfg         *config.Config
	service     serviceInterface
}

func New(accountRepository repository.AccountRepository, tokenRepo repository.AuthTokenRepository, cfg *config.Config) Controller {
	return &controller{
		accountRepo: accountRepository,
		tokenRepo:   tokenRepo,
		cfg:         cfg,
		service:     newService(),
	}
}

type Controller interface {
	CreateAccount(c context.Context, dataRequest parameters.SignupRequest) (*parameters.SignupResponse, error)
	UpdateAccount(c context.Context, dataRequest parameters.UpdateAccountRequest) (*parameters.UpdateAccountResponse, error)
	GetProfile(c context.Context, dataRequest parameters.ProfileRequest) (*parameters.ProfileResponse, error)
	LoginAccount(c context.Context, dataRequest parameters.LoginRequest) (*parameters.LoginResponse, error)
}

func (uc *controller) CreateAccount(c context.Context, dataRequest parameters.SignupRequest) (*parameters.SignupResponse, error) {
	encryptedPassword, err := bcrypt.GenerateFromPassword(
		[]byte(dataRequest.Password),
		bcrypt.DefaultCost,
	)
	if err != nil {
		return nil, response.NewErrorResponse(http.StatusInternalServerError, err, "Something went wrong in the server", "ErrInternal")
	}

	currentTime := time.Now()
	account := models.Account{
		Username:     dataRequest.Username,
		Email:        dataRequest.Email,
		PasswordHash: string(encryptedPassword),
		CreatedAt:    currentTime,
		UpdatedAt:    currentTime,
	}
	if _, err = uc.accountRepo.CreateAccount(c, account); err != nil {
		return nil, err
	}

	resp := parameters.SignupResponse{
		Status: true,
	}
	return &resp, nil
}

func (uc *controller) GetProfile(c context.Context, dataRequest parameters.ProfileRequest) (*parameters.ProfileResponse, error) {
	account, err := uc.accountRepo.GetByAccountID(c, dataRequest.AccountID)
	if err != nil {
		return nil, err
	}

	profile := &parameters.ProfileResponse{
		Username:  account.Username,
		Email:     account.Email,
		FirstName: account.FirstName,
		LastName:  account.LastName,
		Avatar:    account.Avatar,
		Phone:     account.Phone,
	}
	return profile, nil
}

func (uc *controller) LoginAccount(ctx context.Context, dataRequest parameters.LoginRequest) (*parameters.LoginResponse, error) {
	account, err := uc.accountRepo.GetByEmail(ctx, dataRequest.Email)
	if err != nil {
		return nil, err
	}
	if err = bcrypt.CompareHashAndPassword([]byte(account.PasswordHash), []byte(dataRequest.Password)); err != nil {
		return nil, response.NewErrorResponse(http.StatusBadRequest, err, "Email or password is invalid", "ErrEmailOrPasswordInvalid")
	}
	if err = uc.tokenRepo.DeleteTokensByAccountId(ctx, account.ID); err != nil {
		return nil, err
	}

	expiryAccessToken := &gojwt.NumericDate{Time: time.Now().Add(uc.cfg.Jwt.AccessTokenExpiry)}
	expiryRefreshToken := &gojwt.NumericDate{Time: time.Now().Add(uc.cfg.Jwt.RefreshTokenExpiry)}
	currentTime := time.Now()
	tokenData := models.AuthToken{
		AccountId: account.ID,
		ExpireAt:  expiryRefreshToken.Time,
		CreatedAt: currentTime,
	}
	tokenCreated, err := uc.tokenRepo.CreateToken(ctx, tokenData)
	if err != nil {
		return nil, err
	}

	tokenID := tokenCreated.ID.Hex()
	accessToken, err := jwt.CreateToken(jwt.CustomPayload{
		AccountID: account.ID,
		TokenType: constant.TypeAccessToken,
	}, tokenID, uc.cfg.Jwt.SignKey, expiryAccessToken)
	if err != nil {
		return nil, err
	}
	refreshToken, err := jwt.CreateToken(jwt.CustomPayload{
		AccountID: account.ID,
		TokenType: constant.TypeRefreshToken,
	}, tokenID, uc.cfg.Jwt.SignKey, expiryRefreshToken)
	if err != nil {
		return nil, err
	}

	dataResponse := &parameters.LoginResponse{
		AccessToken:  accessToken,
		RefreshToken: refreshToken,
	}
	return dataResponse, nil
}

func (uc *controller) UpdateAccount(c context.Context, dataRequest parameters.UpdateAccountRequest) (*parameters.UpdateAccountResponse, error) {
	if _, err := uc.accountRepo.GetByAccountID(c, dataRequest.AccountID); err != nil {
		return nil, err
	}
	if err := uc.accountRepo.UpdateAccountByID(c, dataRequest.AccountID, dataRequest); err != nil {
		return nil, err
	}

	resp := parameters.UpdateAccountResponse{
		Status: true,
	}
	return &resp, nil
}
