package token

import (
	"context"
	"net/http"
	"time"

	gojwt "github.com/golang-jwt/jwt/v5"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"training-doctor-manager/common/config"
	"training-doctor-manager/common/constant"
	"training-doctor-manager/common/response"
	"training-doctor-manager/pkg/models"
	"training-doctor-manager/pkg/repository"
	"training-doctor-manager/provider/jwt"
)

type controller struct {
	tokenRepo   repository.AuthTokenRepository
	accountRepo repository.AccountRepository
	cfg         *config.Config
}

func New(tokenRepo repository.AuthTokenRepository, accountRepo repository.AccountRepository, cfg *config.Config) Controller {
	return &controller{
		tokenRepo:   tokenRepo,
		accountRepo: accountRepo,
		cfg:         cfg,
	}
}

type Controller interface {
	RefreshToken(c context.Context, requestToken *models.RefreshTokenRequest) (*models.RefreshTokenResponse, error)
}

func (uc *controller) RefreshToken(ctx context.Context, requestToken *models.RefreshTokenRequest) (*models.RefreshTokenResponse, error) {
	var err error
	tokenClaim, err := jwt.ExtractDataFromToken(requestToken.RefreshToken, constant.TypeRefreshToken, uc.cfg.Jwt.VerifyKey)
	if err != nil {
		return nil, err
	}

	account, err := uc.accountRepo.GetByAccountID(ctx, tokenClaim.Payload.AccountID)
	if err != nil {
		return nil, err
	}

	tokenOID, err := primitive.ObjectIDFromHex(tokenClaim.RegisteredClaims.ID)
	if err != nil {
		return nil, response.NewErrorResponse(http.StatusUnauthorized, err, "Unauthorized", "ErrUnauthorized")
	}

	if _, err = uc.tokenRepo.GetTokenByTokenId(ctx, tokenOID); err != nil {
		return nil, err
	}

	if err = uc.tokenRepo.DeleteTokensByAccountId(ctx, account.ID); err != nil {
		return nil, err
	}

	expiryAccessToken := &gojwt.NumericDate{Time: time.Now().Add(uc.cfg.Jwt.AccessTokenExpiry)}
	expiryRefreshToken := &gojwt.NumericDate{Time: time.Now().Add(uc.cfg.Jwt.RefreshTokenExpiry)}
	tokenData := models.AuthToken{
		AccountId: account.ID,
		ExpireAt:  expiryRefreshToken.Time,
	}
	tokenCreated, err := uc.tokenRepo.CreateToken(ctx, tokenData)
	if err != nil {
		return nil, err
	}

	tokenID := tokenCreated.ID.Hex()
	accessToken, err := jwt.CreateToken(jwt.CustomPayload{
		AccountID: account.ID,
		TokenType: constant.TypeAccessToken,
	}, tokenID, uc.cfg.Jwt.SignKey, expiryAccessToken)
	if err != nil {
		return nil, err
	}
	refreshToken, err := jwt.CreateToken(jwt.CustomPayload{
		AccountID: account.ID,
		TokenType: constant.TypeRefreshToken,
	}, tokenID, uc.cfg.Jwt.SignKey, expiryRefreshToken)
	if err != nil {
		return nil, err
	}

	dataResponse := &models.RefreshTokenResponse{
		AccessToken:  accessToken,
		RefreshToken: refreshToken,
	}
	return dataResponse, nil
}
