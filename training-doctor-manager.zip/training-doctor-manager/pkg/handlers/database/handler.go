package database

import (
	"net/http"

	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
	"training-doctor-manager/common/response"
	"training-doctor-manager/pkg/controllers/database"
	"training-doctor-manager/pkg/parameters"
	"training-doctor-manager/util"
)

type handler struct {
	controller database.Controller
	validator  *validator.Validate
}

func NewHandler(controller database.Controller, appValidator *validator.Validate) Handler {
	return &handler{controller: controller, validator: appValidator}
}

type Handler interface {
	CreateDatabase() fiber.Handler
	UpdateDatabase() fiber.Handler
	GetOneDatabase() fiber.Handler
	GetAllDatabase() fiber.Handler
	DeleteDatabase() fiber.Handler
	DeleteDatabases() fiber.Handler
	ListCollections() fiber.Handler
	CreateCollection() fiber.Handler
	DeleteCollection() fiber.Handler
}

func (hdl *handler) CreateCollection() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var dataBody parameters.CollectionCreationBodyRequest
		var dataParam parameters.CollectionCreationParamRequest
		if err := c.ParamsParser(&dataParam); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		if err := c.BodyParser(&dataBody); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		if err := hdl.validator.Struct(dataBody); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		result, err := hdl.controller.CreateCollection(c.Context(), dataBody, dataParam)
		if err != nil {
			return err
		}

		return response.SuccessResponse(c, http.StatusCreated, result)
	}
}

func (hdl *handler) CreateDatabase() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var data parameters.DatabaseCreationRequest

		if err := c.BodyParser(&data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}

		if err := hdl.validator.Struct(data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		result, err := hdl.controller.CreateDatabase(c.Context(), data)
		if err != nil {
			return err
		}

		return response.SuccessResponse(c, http.StatusCreated, result)
	}
}

func (hdl *handler) DeleteCollection() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var dataBody parameters.CollectionDeletionBodyRequest
		var dataParam parameters.CollectionDeletionParamRequest
		if err := c.ParamsParser(&dataParam); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		if err := c.BodyParser(&dataBody); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		if err := hdl.validator.Struct(dataBody); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		result, err := hdl.controller.DeleteCollection(c.Context(), dataBody, dataParam)
		if err != nil {
			return err
		}

		return response.SuccessResponse(c, http.StatusCreated, result)
	}
}

func (hdl *handler) DeleteDatabase() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var data parameters.DatabaseDeletionParamRequest
		if err := c.ParamsParser(&data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}

		result, err := hdl.controller.DeleteDatabase(c.Context(), data)
		if err != nil {
			return err
		}

		return response.SuccessResponse(c, http.StatusOK, result)
	}
}

func (hdl *handler) DeleteDatabases() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var data parameters.DatabaseManyDeletionRequest
		if err := c.BodyParser(&data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		if err := hdl.validator.Struct(data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		result, err := hdl.controller.DeleteDatabases(c.Context(), data)
		if err != nil {
			return err
		}

		return response.SuccessResponse(c, http.StatusOK, result)
	}
}

func (hdl *handler) GetAllDatabase() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var data parameters.DatabaseGetAllRequest
		if err := c.QueryParser(&data.Paging); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		data.Paging.Process()

		if err := c.QueryParser(&data.Filter); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}

		if err := hdl.validator.Struct(data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		result, err := hdl.controller.GetAllDatabase(c.Context(), data)
		if err != nil {
			return err
		}

		return response.SuccessResponse(c, http.StatusOK, result)
	}
}

func (hdl *handler) GetOneDatabase() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var data parameters.DatabaseGetOneRequest
		if err := c.ParamsParser(&data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}

		result, err := hdl.controller.GetOneDatabase(c.Context(), data)
		if err != nil {
			return err
		}

		return response.SuccessResponse(c, http.StatusOK, result)
	}
}

func (hdl *handler) ListCollections() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var dataQuery parameters.CollectionListQueryRequest
		var dataParam parameters.CollectionListParamRequest
		dataQuery.Filter.CollectionName = c.Query("collection_name")
		if err := c.ParamsParser(&dataParam); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		if err := c.QueryParser(&dataQuery.Paging); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		dataQuery.Paging.Process()
		if err := hdl.validator.Struct(dataQuery); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		result, err := hdl.controller.ListCollections(c.Context(), dataQuery, dataParam)
		if err != nil {
			return err
		}

		return response.SuccessResponse(c, http.StatusOK, result)
	}
}

func (hdl *handler) UpdateDatabase() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var dataBody parameters.DatabaseUpdateBodyRequest
		var dataParam parameters.DatabaseUpdateParamRequest
		if err := c.BodyParser(&dataBody); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		if err := c.ParamsParser(&dataParam); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		if err := hdl.validator.Struct(dataBody); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		result, err := hdl.controller.UpdateDatabase(c.Context(), dataBody, dataParam)
		if err != nil {
			return err
		}
		return response.SuccessResponse(c, http.StatusOK, result)
	}
}
