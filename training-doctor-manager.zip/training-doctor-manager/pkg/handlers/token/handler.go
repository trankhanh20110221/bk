package token

import (
	"errors"
	"net/http"

	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
	"training-doctor-manager/common/response"
	"training-doctor-manager/pkg/controllers/token"
	"training-doctor-manager/pkg/parameters"
)

type handler struct {
	controller token.Controller
	validator  *validator.Validate
}

func NewHandler(controller token.Controller, validator *validator.Validate) Handler {
	return &handler{controller: controller, validator: validator}
}

type Handler interface {
	RefreshToken() fiber.Handler
}

func (hdl *handler) RefreshToken() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var dataRequest parameters.RefreshTokenRequest

		if err := c.BodyParser(&dataRequest); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}

		validate := validator.New()

		err := validate.Struct(dataRequest)
		if err != nil {
			var errs validator.ValidationErrors
			errors.As(err, &errs)
			return response.NewErrorResponse(http.StatusBadRequest, errs, "Validation error", "ErrValidation")
		}

		dataResponse, err := hdl.controller.RefreshToken(c.Context(), &dataRequest)
		if err != nil {
			return err
		}

		return response.SuccessResponse(c, http.StatusOK, dataResponse)
	}
}
