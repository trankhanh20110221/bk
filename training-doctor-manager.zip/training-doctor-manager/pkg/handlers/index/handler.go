package index

import (
	"errors"
	"net/http"

	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"training-doctor-manager/common/constant"
	"training-doctor-manager/common/response"
	"training-doctor-manager/pkg/controllers/index"
	"training-doctor-manager/pkg/parameters"
	"training-doctor-manager/util"
	"training-doctor-manager/util/local"
)

type handler struct {
	controller index.Controller
	validator  *validator.Validate
}

func NewHandler(controller index.Controller, appValidator *validator.Validate) Handler {
	return &handler{controller: controller, validator: appValidator}
}

type Handler interface {
	GetIndexes() fiber.Handler
	GetIndex() fiber.Handler
	CreateIndex() fiber.Handler
	UpdateIndex() fiber.Handler
	DeleteIndex() fiber.Handler
	DeleteIndexes() fiber.Handler
	SyncIndexesByDatabase() fiber.Handler
	SyncIndexesByCollection() fiber.Handler
	CompareIndexesByCollection() fiber.Handler
	CompareIndexesByDatabase() fiber.Handler
}

func (hdl *handler) CompareIndexesByCollection() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var data parameters.IndexCompareCollectionRequest
		if err := c.BodyParser(&data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}

		if err := hdl.validator.Struct(data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		result, err := hdl.controller.CompareIndexesByCollection(c.Context(), data)
		if err != nil {
			return err
		}

		return response.SuccessResponse(c, http.StatusOK, result)
	}
}

func (hdl *handler) CompareIndexesByDatabase() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var data parameters.IndexCompareDatabaseRequest
		if err := c.BodyParser(&data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}

		if err := hdl.validator.Struct(data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		result, err := hdl.controller.CompareIndexesByDatabase(c.Context(), data)
		if err != nil {
			return err
		}

		return response.SuccessResponse(c, http.StatusOK, result)
	}
}

func (hdl *handler) CreateIndex() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var data parameters.IndexCreationRequest
		if err := c.BodyParser(&data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		data.RemoveSpaceInKeyFields()

		if err := hdl.validator.Struct(data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		for _, key := range data.Keys {
			if err := hdl.validator.Struct(key); err != nil {
				return response.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
			}
		}

		totalKeys := len(data.Keys)
		if totalKeys > 1 && data.Options.ExpireAfterSeconds != nil {
			return response.NewErrorResponse(http.StatusBadRequest, errors.New("error validation"), "Cannot have ExpireAfterSeconds option in compound index", "ErrValidation")
		}

		result, err := hdl.controller.CreateIndex(c.Context(), data)
		if err != nil {
			return err
		}

		return response.SuccessResponse(c, http.StatusOK, result)
	}
}

func (hdl *handler) DeleteIndex() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var data parameters.IndexDeletionRequest
		OID, err := primitive.ObjectIDFromHex(c.Params("id"))
		if err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		data.ID = OID

		if err = hdl.validator.Struct(data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		result, err := hdl.controller.DeleteIndex(c.Context(), data)
		if err != nil {
			return err
		}

		return response.SuccessResponse(c, http.StatusOK, result)
	}
}

func (hdl *handler) DeleteIndexes() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var data parameters.IndexManyDeletionRequest
		if err := c.BodyParser(&data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		if err := hdl.validator.Struct(data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		result, err := hdl.controller.DeleteIndexes(c.Context(), data)
		if err != nil {
			return err
		}

		return response.SuccessResponse(c, http.StatusOK, result)
	}
}

func (hdl *handler) GetIndex() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var err error
		var data parameters.IndexGetOneRequest
		data.IndexID, err = primitive.ObjectIDFromHex(c.Params("index_id"))
		if err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}

		if err = hdl.validator.Struct(data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		result, err := hdl.controller.GetIndex(c.Context(), data)
		if err != nil {
			return err
		}

		return response.SuccessResponse(c, http.StatusOK, result)
	}
}

func (hdl *handler) GetIndexes() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var err error
		var data parameters.IndexGetAllRequest
		data.DatabaseID, err = primitive.ObjectIDFromHex(c.Query("database_id"))
		data.CollectionName = c.Query("collection")
		if err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}

		if err = hdl.validator.Struct(data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		result, err := hdl.controller.GetIndexes(c.Context(), data)
		if err != nil {
			return err
		}

		return response.SuccessResponse(c, http.StatusOK, result)
	}
}

func (hdl *handler) SyncIndexesByCollection() fiber.Handler {
	return func(c *fiber.Ctx) error {
		data := parameters.IndexSyncCollectionRequest{
			OptionExtra:   constant.OptionSyncForward,
			OptionMissing: constant.OptionSyncForward,
		}
		if err := c.BodyParser(&data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		if err := hdl.validator.Struct(data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		data.UserID = local.New(c).GetUser().ID
		result, err := hdl.controller.SyncIndexesByCollection(c.Context(), data)
		if err != nil {
			return err
		}

		return response.SuccessResponse(c, http.StatusOK, result)
	}
}

func (hdl *handler) SyncIndexesByDatabase() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var data parameters.IndexSyncDatabaseRequest
		if err := c.BodyParser(&data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		data.UserID = local.New(c).GetUser().ID

		if err := hdl.validator.Struct(data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		result, err := hdl.controller.SyncIndexesByDatabase(c.Context(), data)
		if err != nil {
			return err
		}

		return response.SuccessResponse(c, http.StatusOK, result)
	}
}

func (hdl *handler) UpdateIndex() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var dataBody parameters.IndexUpdateBodyRequest
		var dataParam parameters.IndexUpdateParamRequest
		if err := c.ParamsParser(&dataParam); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		if err := c.BodyParser(&dataBody); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		dataBody.RemoveSpaceInKeyFields()
		if err := hdl.validator.Struct(dataBody); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}
		for _, key := range dataBody.Keys {
			if err := hdl.validator.Struct(key); err != nil {
				return response.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
			}
		}
		totalKeys := len(dataBody.Keys)
		if totalKeys > 1 && dataBody.Options.ExpireAfterSeconds != nil {
			return response.NewErrorResponse(http.StatusBadRequest, errors.New("error validation"), "Cannot have ExpireAfterSeconds option in compound index", "ErrValidation")
		}

		result, err := hdl.controller.UpdateIndex(c.Context(), dataBody, dataParam)
		if err != nil {
			return err
		}

		return response.SuccessResponse(c, http.StatusOK, result)
	}
}
