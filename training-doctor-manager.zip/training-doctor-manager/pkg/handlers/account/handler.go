package account

import (
	"net/http"

	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
	"training-doctor-manager/common/response"
	"training-doctor-manager/pkg/controllers/account"
	"training-doctor-manager/pkg/parameters"
	"training-doctor-manager/util"
	"training-doctor-manager/util/local"
)

type handler struct {
	controller account.Controller
	validator  *validator.Validate
}

func NewHandler(controller account.Controller, appValidator *validator.Validate) Handler {
	return &handler{controller: controller, validator: appValidator}
}

type Handler interface {
	Signup() fiber.Handler
	GetProfile() fiber.Handler
	Login() fiber.Handler
	UpdateAccount() fiber.Handler
}

func (hdl *handler) Signup() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var data parameters.SignupRequest

		if err := c.BodyParser(&data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}

		if err := hdl.validator.Struct(data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		result, err := hdl.controller.CreateAccount(c.Context(), data)
		if err != nil {
			return err
		}

		return response.SuccessResponse(c, http.StatusCreated, result)
	}
}

func (hdl *handler) GetProfile() fiber.Handler {
	return func(c *fiber.Ctx) error {
		accountId := local.New(c).GetUser().ID
		data := parameters.ProfileRequest{AccountID: accountId}

		result, err := hdl.controller.GetProfile(c.Context(), data)
		if err != nil {
			return err
		}

		return response.SuccessResponse(c, http.StatusOK, result)
	}
}

func (hdl *handler) Login() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var data parameters.LoginRequest

		if err := c.BodyParser(&data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}

		if err := hdl.validator.Struct(data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		result, err := hdl.controller.LoginAccount(c.Context(), data)
		if err != nil {
			return err
		}

		return response.SuccessResponse(c, http.StatusOK, result)
	}
}

func (hdl *handler) UpdateAccount() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var data parameters.UpdateAccountRequest
		if err := c.BodyParser(&data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		if err := hdl.validator.Struct(data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		data.AccountID = local.New(c).GetUser().ID
		result, err := hdl.controller.UpdateAccount(c.Context(), data)
		if err != nil {
			return err
		}
		return response.SuccessResponse(c, http.StatusCreated, result)
	}
}
