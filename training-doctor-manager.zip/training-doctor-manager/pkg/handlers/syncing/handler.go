package syncing

import (
	"net/http"

	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
	"training-doctor-manager/common/response"
	"training-doctor-manager/pkg/controllers/syncing"
	"training-doctor-manager/pkg/parameters"
)

type handler struct {
	controller syncing.Controller
	validator  *validator.Validate
}

func NewHandler(controller syncing.Controller, appValidator *validator.Validate) Handler {
	return &handler{controller: controller, validator: appValidator}
}

type Handler interface {
	GetAllSyncing() fiber.Handler
	DeleteSyncing() fiber.Handler
}

func (hdl *handler) DeleteSyncing() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var data parameters.SyncingDeletionRequest
		if err := c.ParamsParser(&data); err != nil {
			return response.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}

		result, err := hdl.controller.DeleteSyncing(c.Context(), data)
		if err != nil {
			return err
		}

		return response.SuccessResponse(c, http.StatusOK, result)
	}
}

func (hdl *handler) GetAllSyncing() fiber.Handler {
	return func(c *fiber.Ctx) error {
		result, err := hdl.controller.GetAllSyncing(c.Context())
		if err != nil {
			return err
		}
		return response.SuccessResponse(c, http.StatusOK, result)
	}
}
