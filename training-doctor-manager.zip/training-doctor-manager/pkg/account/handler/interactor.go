package accounthandler

import (
	"net/http"

	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
	"training-doctor-manager/common"
	"training-doctor-manager/pkg/account/model"
	"training-doctor-manager/pkg/account/usecase"
	"training-doctor-manager/util"
	"training-doctor-manager/util/local"
)

type accountHandler struct {
	accountUC usecase.AccountUsecase
	validator *validator.Validate
}

func NewAccountHandler(accountUseCase usecase.AccountUsecase, appValidator *validator.Validate) AccountHandler {
	return &accountHandler{accountUC: accountUseCase, validator: appValidator}
}

type AccountHandler interface {
	Signup() fiber.Handler
	GetProfile() fiber.Handler
	Login() fiber.Handler
	UpdateAccount() fiber.Handler
}

func (hdl *accountHandler) Signup() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var data model.SignupRequest

		if err := c.BodyParser(&data); err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}

		if err := hdl.validator.Struct(data); err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		result, err := hdl.accountUC.CreateAccount(c.Context(), data)
		if err != nil {
			return err
		}

		return common.SuccessResponse(c, http.StatusCreated, result)
	}
}

func (hdl *accountHandler) GetProfile() fiber.Handler {
	return func(c *fiber.Ctx) error {
		localStorage := local.New(c)
		accountId := localStorage.GetUser().ID
		data := model.ProfileRequest{AccountID: accountId}

		result, err := hdl.accountUC.GetProfile(c.Context(), data)
		if err != nil {
			return err
		}

		return common.SuccessResponse(c, http.StatusOK, result)
	}
}

func (hdl *accountHandler) Login() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var data model.LoginRequest

		if err := c.BodyParser(&data); err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}

		if err := hdl.validator.Struct(data); err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		result, err := hdl.accountUC.LoginAccount(c.Context(), data)
		if err != nil {
			return err
		}

		return common.SuccessResponse(c, http.StatusOK, result)
	}
}

func (hdl *accountHandler) UpdateAccount() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var data model.UpdateAccountRequest
		if err := c.BodyParser(&data); err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		if err := hdl.validator.Struct(data); err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		data.AccountID = local.New(c).GetUser().ID
		result, err := hdl.accountUC.UpdateAccount(c.Context(), data)
		if err != nil {
			return err
		}
		return common.SuccessResponse(c, http.StatusCreated, result)
	}
}
