package model

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

const (
	CollectionAccount = "accounts"
)

type Account struct {
	CreatedAt    time.Time          `bson:"created_at"`
	UpdatedAt    time.Time          `bson:"updated_at"`
	Username     string             `bson:"username"`
	FirstName    string             `bson:"first_name"`
	LastName     string             `bson:"last_name"`
	Avatar       string             `bson:"avatar"`
	Phone        string             `bson:"phone"`
	Email        string             `bson:"email"`
	PasswordHash string             `bson:"password_hash"`
	ID           primitive.ObjectID `bson:"_id,omitempty"`
}

type ProfileRequest struct {
	AccountID primitive.ObjectID
}

type ProfileResponse struct {
	Username  string `json:"username"`
	Email     string `json:"email"`
	FirstName string `json:"first_name"`
	LastName  string `json:"last_name"`
	Avatar    string `json:"avatar"`
	Phone     string `json:"phone"`
}

type SignupRequest struct {
	Username string `json:"username" validate:"required"`
	Email    string `json:"email" validate:"required,email"`
	Password string `json:"password" validate:"required,gte=8"`
}

type SignupResponse struct {
	Status bool `json:"status"`
}

type UpdateAccountRequest struct {
	FirstName string `json:"first_name,omitempty"`
	LastName  string `json:"last_name,omitempty"`
	Avatar    string `json:"avatar,omitempty"`
	Phone     string `json:"phone,omitempty" validate:"gte=10,lte=10"`
	AccountID primitive.ObjectID
}

type UpdateAccountResponse struct {
	Status bool `json:"status"`
}

type LoginRequest struct {
	Email    string `json:"email" validate:"required,email"`
	Password string `json:"password" validate:"required"`
}

type LoginResponse struct {
	AccessToken  string `json:"access_token"`
	RefreshToken string `json:"refresh_token"`
}
