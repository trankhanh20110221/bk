package indexhandler

import (
	"errors"
	"net/http"

	"github.com/gofiber/fiber/v2"
	"training-doctor-manager/common"
	"training-doctor-manager/pkg/index/model"
	"training-doctor-manager/util"
)

func (hdl *indexHandler) CreateIndex() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var data model.IndexCreationRequest
		if err := c.BodyParser(&data); err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		data.RemoveSpaceInKeyFields()

		if err := hdl.validator.Struct(data); err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		for _, key := range data.Keys {
			if err := hdl.validator.Struct(key); err != nil {
				return common.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
			}
		}

		totalKeys := len(data.Keys)
		if totalKeys > 1 && data.Options.ExpireAfterSeconds != nil {
			return common.NewErrorResponse(http.StatusBadRequest, errors.New("error validation"), "Cannot have ExpireAfterSeconds option in compound index", "ErrValidation")
		}

		result, err := hdl.indexUC.CreateIndex(c.Context(), data)
		if err != nil {
			return err
		}

		return common.SuccessResponse(c, http.StatusOK, result)
	}
}
