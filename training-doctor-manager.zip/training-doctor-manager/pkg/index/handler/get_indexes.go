package indexhandler

import (
	"net/http"

	"github.com/gofiber/fiber/v2"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"training-doctor-manager/common"
	"training-doctor-manager/pkg/index/model"
	"training-doctor-manager/util"
)

func (hdl *indexHandler) GetIndexes() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var err error
		var data model.IndexGetAllRequest
		data.DatabaseID, err = primitive.ObjectIDFromHex(c.Query("database_id"))
		data.CollectionName = c.Query("collection")
		if err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}

		if err = hdl.validator.Struct(data); err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		result, err := hdl.indexUC.GetIndexes(c.Context(), data)
		if err != nil {
			return err
		}

		return common.SuccessResponse(c, http.StatusOK, result)
	}
}
