package indexhandler

import (
	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
	"training-doctor-manager/pkg/index/usecase"
)

type indexHandler struct {
	indexUC   usecase.IndexUsecase
	validator *validator.Validate
}

func NewIndexHandler(indexUseCase usecase.IndexUsecase, appValidator *validator.Validate) IndexHandler {
	return &indexHandler{indexUC: indexUseCase, validator: appValidator}
}

type IndexHandler interface {
	GetIndexes() fiber.Handler
	GetIndex() fiber.Handler
	CreateIndex() fiber.Handler
	UpdateIndex() fiber.Handler
	DeleteIndex() fiber.Handler
	DeleteIndexes() fiber.Handler
	SyncIndexesByDatabase() fiber.Handler
	SyncIndexesByCollection() fiber.Handler
	CompareIndexesByCollection() fiber.Handler
	CompareIndexesByDatabase() fiber.Handler
}
