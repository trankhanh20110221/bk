package indexhandler

import (
	"net/http"

	"github.com/gofiber/fiber/v2"
	"training-doctor-manager/common"
	"training-doctor-manager/pkg/index/model"
	"training-doctor-manager/util"
	"training-doctor-manager/util/local"
)

func (hdl *indexHandler) SyncIndexesByDatabase() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var data model.IndexSyncDatabaseRequest
		if err := c.BodyParser(&data); err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		data.UserID = local.New(c).GetUser().ID

		if err := hdl.validator.Struct(data); err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		result, err := hdl.indexUC.SyncIndexesByDatabase(c.Context(), data)
		if err != nil {
			return err
		}

		return common.SuccessResponse(c, http.StatusOK, result)
	}
}
