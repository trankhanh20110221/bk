package indexhandler

import (
	"errors"
	"net/http"

	"github.com/gofiber/fiber/v2"
	"training-doctor-manager/common"
	"training-doctor-manager/pkg/index/model"
	"training-doctor-manager/util"
)

func (hdl *indexHandler) UpdateIndex() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var dataBody model.IndexUpdateBodyRequest
		var dataParam model.IndexUpdateParamRequest
		if err := c.ParamsParser(&dataParam); err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		if err := c.BodyParser(&dataBody); err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		dataBody.RemoveSpaceInKeyFields()
		if err := hdl.validator.Struct(dataBody); err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}
		for _, key := range dataBody.Keys {
			if err := hdl.validator.Struct(key); err != nil {
				return common.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
			}
		}
		totalKeys := len(dataBody.Keys)
		if totalKeys > 1 && dataBody.Options.ExpireAfterSeconds != nil {
			return common.NewErrorResponse(http.StatusBadRequest, errors.New("error validation"), "Cannot have ExpireAfterSeconds option in compound index", "ErrValidation")
		}

		result, err := hdl.indexUC.UpdateIndex(c.Context(), dataBody, dataParam)
		if err != nil {
			return err
		}

		return common.SuccessResponse(c, http.StatusOK, result)
	}
}
