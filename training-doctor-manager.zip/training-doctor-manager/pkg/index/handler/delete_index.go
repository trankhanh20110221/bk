package indexhandler

import (
	"net/http"

	"github.com/gofiber/fiber/v2"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"training-doctor-manager/common"
	"training-doctor-manager/pkg/index/model"
	"training-doctor-manager/util"
)

func (hdl *indexHandler) DeleteIndex() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var data model.IndexDeletionRequest
		OID, err := primitive.ObjectIDFromHex(c.Params("id"))
		if err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		data.ID = OID

		if err = hdl.validator.Struct(data); err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		result, err := hdl.indexUC.DeleteIndex(c.Context(), data)
		if err != nil {
			return err
		}

		return common.SuccessResponse(c, http.StatusOK, result)
	}
}
