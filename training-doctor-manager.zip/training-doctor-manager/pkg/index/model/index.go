package model

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

const (
	CollectionIndex = "indexes"
)

type Index struct {
	CreatedAt  time.Time          `bson:"created_at"`
	UpdatedAt  time.Time          `bson:"updated_at"`
	Options    IndexOption        `bson:"options"`
	Collection string             `bson:"collection"`
	Name       string             `bson:"name"`
	KeyString  string             `bson:"key_string"`
	Keys       []IndexKey         `bson:"keys"`
	ID         primitive.ObjectID `bson:"_id,omitempty"`
	DatabaseID primitive.ObjectID `bson:"database_id"`
}

type IndexResponse struct {
	CreatedAt  time.Time           `json:"created_at"`
	UpdatedAt  time.Time           `json:"updated_at"`
	Options    IndexOptionResponse `json:"options,omitempty"`
	Collection string              `json:"collection"`
	Name       string              `json:"name"`
	Keys       []IndexKeyResponse  `json:"keys"`
	ID         primitive.ObjectID  `json:"id"`
	DatabaseID primitive.ObjectID  `json:"database_id"`
}

type IndexCreationRequest struct {
	Options    IndexOptionRequest `json:"options"`
	Name       string             `json:"name"`
	Collection string             `json:"collection" validate:"required"`
	Keys       []*IndexKeyRequest `json:"keys" validate:"required,gte=1,mongo_index_field"`
	DatabaseID primitive.ObjectID `json:"database_id" validate:"required"`
}

type IndexCreationResponse struct {
	ID string `json:"id"`
}

type IndexUpdateBodyRequest struct {
	Options IndexOptionRequest `json:"options,omitempty"`
	Name    string             `json:"name,omitempty"`
	Keys    []*IndexKeyRequest `json:"keys" validate:"required,gte=1,mongo_index_field"`
}

type IndexUpdateParamRequest struct {
	ID primitive.ObjectID `params:"index_id"`
}

type IndexUpdateResponse struct {
	Status bool `json:"status"`
}

type IndexDeletionRequest struct {
	ID primitive.ObjectID `validate:"required"`
}

type IndexDeletionResponse struct {
	Status bool `json:"status"`
}

type IndexManyDeletionRequest struct {
	IDs []primitive.ObjectID `json:"ids" validate:"required"`
}

type IndexManyDeletionResponse struct {
	Status bool `json:"status"`
}

type IndexGetOneRequest struct {
	IndexID primitive.ObjectID `validate:"required"`
}

type IndexGetAllRequest struct {
	CollectionName string             `query:"collection" validate:"required"`
	DatabaseID     primitive.ObjectID `validate:"required"`
}

type IndexGetAllResponse struct {
	Data []IndexResponse `json:"records"`
}

type IndexKey struct {
	Field string `bson:"field"`
	Value int32  `bson:"value"`
}

type IndexKeyRequest struct {
	Field string `json:"field" validate:"required,mongo_index_default_invalid"`
	Value int32  `json:"value" validate:"required,mongo_index_value"`
}

type IndexKeyResponse struct {
	Field string `json:"field"`
	Value int32  `json:"value"`
}

type IndexOption struct {
	ExpireAfterSeconds *int32 `bson:"expire_after_seconds"`
	IsUnique           bool   `bson:"is_unique"`
}

type IndexOptionRequest struct {
	ExpireAfterSeconds *int32 `json:"expire_after_seconds" validate:"omitempty,min=0"`
	IsUnique           bool   `json:"is_unique"`
}

type IndexOptionResponse struct {
	ExpireAfterSeconds *int32 `json:"expire_after_seconds,omitempty"`
	IsUnique           bool   `json:"is_unique,omitempty"`
}

type IndexSyncCollectionRequest struct {
	CollectionName string `json:"collection_name" validate:"required"`
	OptionExtra    int    `json:"option_extra,omitempty"`
	OptionMissing  int    `json:"option_missing,omitempty"`
	UserID         primitive.ObjectID
	DatabaseID     primitive.ObjectID `json:"database_id" validate:"required"`
}

type IndexSyncCollectionResponse struct {
	Status bool `json:"status"`
}

type IndexSyncDatabaseRequest struct {
	UserID        primitive.ObjectID
	DatabaseID    primitive.ObjectID `json:"database_id" validate:"required"`
	OptionExtra   int                `json:"option_extra"`
	OptionMissing int                `json:"option_missing"`
}

type IndexSyncDatabaseResponse struct {
	Status bool `json:"status"`
}

type IndexCompare struct {
	Options   IndexOptionResponse `json:"options,omitempty"`
	Name      string              `json:"name"`
	KeyString string              `json:"-"`
	Keys      []IndexKeyResponse  `json:"keys"`
}

type IndexCompareCollectionRequest struct {
	CollectionName string             `json:"collection_name" validate:"required"`
	DatabaseID     primitive.ObjectID `json:"database_id" validate:"required"`
}

type IndexCompareCollectionResponse struct {
	MissingIndexes []IndexCompare `json:"missing_indexes"`
	MatchedIndexes []IndexCompare `json:"matched_indexes"`
	ExtraIndexes   []IndexCompare `json:"extra_indexes"`
}

type IndexCompareDatabaseRequest struct {
	DatabaseID primitive.ObjectID `json:"database_id" validate:"required"`
}

type IndexCompareDatabaseResponse struct {
	Result []IndexCompareDatabaseElement `json:"result"`
}

type IndexCompareDatabaseElement struct {
	CollectionName string         `json:"collection_name"`
	MissingIndexes []IndexCompare `json:"missing_indexes"`
	MatchedIndexes []IndexCompare `json:"matched_indexes"`
	ExtraIndexes   []IndexCompare `json:"extra_indexes"`
}
