package model

import (
	"fmt"
	"strings"
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

func (i Index) ToKeyString() string {
	var keyString string
	for _, key := range i.Keys {
		keyString += fmt.Sprintf("%s_%d_", key.Field, key.Value)
	}
	if i.Options.IsUnique {
		keyString += "unique_"
	}
	if i.Options.ExpireAfterSeconds != nil {
		keyString += fmt.Sprintf("expire_%d", *i.Options.ExpireAfterSeconds)
	}
	return keyString
}

func ToIndexKeyResponseArr(data []IndexKey) []IndexKeyResponse {
	result := make([]IndexKeyResponse, len(data))
	for i, v := range data {
		result[i] = IndexKeyResponse{
			Field: v.Field,
			Value: v.Value,
		}
	}
	return result
}

func ToIndexKeyModelArr(data []*IndexKeyRequest) []IndexKey {
	result := make([]IndexKey, len(data))
	for i, v := range data {
		result[i] = IndexKey{
			Field: v.Field,
			Value: v.Value,
		}
	}
	return result
}

func ToMongoIndexArr(data []IndexCompare) []mongo.IndexModel {
	result := make([]mongo.IndexModel, len(data))
	for i, v := range data {
		indexKeys := bson.D{}
		for _, value := range v.Keys {
			k := bson.E{Key: value.Field, Value: value.Value}
			indexKeys = append(indexKeys, k)
		}

		indexModel := mongo.IndexModel{
			Keys: indexKeys,
		}
		indexModel.Options = options.Index().SetUnique(v.Options.IsUnique)
		indexModel.Options.SetName(v.KeyString)
		if v.Options.ExpireAfterSeconds != nil {
			indexModel.Options = options.Index().SetExpireAfterSeconds(*v.Options.ExpireAfterSeconds)
		}
		result[i] = indexModel
	}
	return result
}

func ToIndexModelArr(data []IndexCompare, databaseID primitive.ObjectID, collection string) []Index {
	result := make([]Index, len(data))
	currentTime := time.Now()

	for i, v := range data {
		index := Index{
			DatabaseID: databaseID,
			Collection: collection,
			Keys:       make([]IndexKey, len(v.Keys)),
			CreatedAt:  currentTime,
			UpdatedAt:  currentTime,
			Options: IndexOption{
				ExpireAfterSeconds: v.Options.ExpireAfterSeconds,
				IsUnique:           v.Options.IsUnique,
			},
		}
		for idx := range v.Keys {
			index.Keys[idx].Field = v.Keys[idx].Field
			index.Keys[idx].Value = v.Keys[idx].Value
		}
		index.KeyString = index.ToKeyString()
		index.Name = index.KeyString
		result[i] = index
	}

	return result
}

func ToIndexCompareResponse(data *Index) IndexCompare {
	return IndexCompare{
		Name: data.Name,
		Keys: ToIndexKeyResponseArr(data.Keys),
		Options: IndexOptionResponse{
			IsUnique:           data.Options.IsUnique,
			ExpireAfterSeconds: data.Options.ExpireAfterSeconds,
		},
		KeyString: data.KeyString,
	}
}

func ToIndexModel(index primitive.D) *Index {
	indexModel := new(Index)
	indexModel.Keys = make([]IndexKey, 0)
	for _, element := range index {
		switch element.Key {
		case "name":
			indexModel.Name, _ = element.Value.(string)
		case "key":
			for _, k := range element.Value.(primitive.D) {
				indexValue, ok := k.Value.(int32)
				if ok {
					indexModel.Keys = append(indexModel.Keys, IndexKey{
						Field: k.Key,
						Value: indexValue,
					})
				}
			}
		case "collection":
			indexModel.Collection, _ = element.Value.(string)
		case "unique":
			indexModel.Options.IsUnique, _ = element.Value.(bool)
		case "expireAfterSeconds":
			expireValue := element.Value.(int32)
			indexModel.Options.ExpireAfterSeconds = &expireValue
		}
	}
	return indexModel
}

func ToNameFromKeys(keys []IndexKey) string {
	var keyString string
	for _, key := range keys {
		keyString += fmt.Sprintf("%s_%d_", key.Field, key.Value)
	}
	return keyString[:len(keyString)-1]
}

func (data *IndexCreationRequest) RemoveSpaceInKeyFields() {
	for _, key := range data.Keys {
		key.Field = strings.ReplaceAll(key.Field, " ", "")
	}
}

func (data *IndexUpdateBodyRequest) RemoveSpaceInKeyFields() {
	for _, key := range data.Keys {
		key.Field = strings.ReplaceAll(key.Field, " ", "")
	}
}
