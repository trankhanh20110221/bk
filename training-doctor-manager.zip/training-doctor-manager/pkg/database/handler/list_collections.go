package databasehandler

import (
	"net/http"

	"github.com/gofiber/fiber/v2"
	"training-doctor-manager/common"
	"training-doctor-manager/pkg/database/model"
	"training-doctor-manager/util"
)

func (hdl *databaseHandler) ListCollections() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var dataQuery model.CollectionListQueryRequest
		var dataParam model.CollectionListParamRequest
		dataQuery.Filter.CollectionName = c.Query("collection_name")
		if err := c.ParamsParser(&dataParam); err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		if err := c.QueryParser(&dataQuery.Paging); err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		dataQuery.Paging.Process()
		if err := hdl.validator.Struct(dataQuery); err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		result, err := hdl.databaseUC.ListCollections(c.Context(), dataQuery, dataParam)
		if err != nil {
			return err
		}

		return common.SuccessResponse(c, http.StatusOK, result)
	}
}
