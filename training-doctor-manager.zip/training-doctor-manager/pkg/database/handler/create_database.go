package databasehandler

import (
	"net/http"

	"github.com/gofiber/fiber/v2"
	"training-doctor-manager/common"
	"training-doctor-manager/pkg/database/model"
	"training-doctor-manager/util"
)

func (hdl *databaseHandler) CreateDatabase() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var data model.DatabaseCreationRequest

		if err := c.BodyParser(&data); err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}

		if err := hdl.validator.Struct(data); err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		result, err := hdl.databaseUC.CreateDatabase(c.Context(), data)
		if err != nil {
			return err
		}

		return common.SuccessResponse(c, http.StatusCreated, result)
	}
}
