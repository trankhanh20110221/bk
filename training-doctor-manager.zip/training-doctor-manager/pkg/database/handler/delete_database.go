package databasehandler

import (
	"net/http"

	"github.com/gofiber/fiber/v2"
	"training-doctor-manager/common"
	"training-doctor-manager/pkg/database/model"
)

func (hdl *databaseHandler) DeleteDatabase() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var data model.DatabaseDeletionParamRequest
		if err := c.ParamsParser(&data); err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}

		result, err := hdl.databaseUC.DeleteDatabase(c.Context(), data)
		if err != nil {
			return err
		}

		return common.SuccessResponse(c, http.StatusOK, result)
	}
}
