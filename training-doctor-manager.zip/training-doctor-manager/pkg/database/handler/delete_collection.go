package databasehandler

import (
	"net/http"

	"github.com/gofiber/fiber/v2"
	"training-doctor-manager/common"
	"training-doctor-manager/pkg/database/model"
	"training-doctor-manager/util"
)

func (hdl *databaseHandler) DeleteCollection() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var dataBody model.CollectionDeletionBodyRequest
		var dataParam model.CollectionDeletionParamRequest
		if err := c.ParamsParser(&dataParam); err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		if err := c.BodyParser(&dataBody); err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}
		if err := hdl.validator.Struct(dataBody); err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, util.ParseValidationMessage(err), "ErrValidation")
		}

		result, err := hdl.databaseUC.DeleteCollection(c.Context(), dataBody, dataParam)
		if err != nil {
			return err
		}

		return common.SuccessResponse(c, http.StatusCreated, result)
	}
}
