package databasehandler

import (
	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
	"training-doctor-manager/pkg/database/usecase"
)

type databaseHandler struct {
	databaseUC usecase.DatabaseUsecase
	validator  *validator.Validate
}

func NewDatabaseHandler(databaseUseCase usecase.DatabaseUsecase, appValidator *validator.Validate) DatabaseHandler {
	return &databaseHandler{databaseUC: databaseUseCase, validator: appValidator}
}

type DatabaseHandler interface {
	CreateDatabase() fiber.Handler
	UpdateDatabase() fiber.Handler
	GetOneDatabase() fiber.Handler
	GetAllDatabase() fiber.Handler
	DeleteDatabase() fiber.Handler
	DeleteDatabases() fiber.Handler
	ListCollections() fiber.Handler
	CreateCollection() fiber.Handler
	DeleteCollection() fiber.Handler
}
