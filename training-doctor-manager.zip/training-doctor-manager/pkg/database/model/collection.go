package model

import (
	"go.mongodb.org/mongo-driver/bson/primitive"
	"training-doctor-manager/common"
)

type CollectionResponse struct {
	CollectionName string `json:"collection" bson:"collection"`
	TotalIndexes   int    `json:"total_indexes"`
}

type CollectionListQueryRequest struct {
	Filter FilterCollection
	Paging common.Paging
}

type CollectionListParamRequest struct {
	DatabaseID primitive.ObjectID `params:"id"`
}

type CollectionListResponse struct {
	Paging  *common.Paging        `json:"paging"`
	Records []*CollectionResponse `json:"records"`
}

type CollectionCreationBodyRequest struct {
	CollectionName string `json:"collection" validate:"required"`
}

type CollectionCreationParamRequest struct {
	DatabaseID primitive.ObjectID `params:"id"`
}

type CollectionCreationResponse struct {
	Status bool `json:"status"`
}

type CollectionDeletionBodyRequest struct {
	CollectionName string `json:"collection" validate:"required"`
}

type CollectionDeletionParamRequest struct {
	DatabaseID primitive.ObjectID `params:"id"`
}

type CollectionDeletionResponse struct {
	Status bool `json:"status"`
}

type FilterCollection struct {
	CollectionName string `query:"collection_name"`
}
