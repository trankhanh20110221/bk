package syncinghandler

import (
	"net/http"

	"github.com/gofiber/fiber/v2"
	"training-doctor-manager/common"
)

func (hdl *syncingHandler) GetAllSyncing() fiber.Handler {
	return func(c *fiber.Ctx) error {
		result, err := hdl.syncingUC.GetAllSyncing(c.Context())
		if err != nil {
			return err
		}
		return common.SuccessResponse(c, http.StatusOK, result)
	}
}
