package syncinghandler

import (
	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
	"training-doctor-manager/pkg/syncing/usecase"
)

type syncingHandler struct {
	syncingUC usecase.SyncingUsecase
	validator *validator.Validate
}

func NewSyncingHandler(syncingUseCase usecase.SyncingUsecase, appValidator *validator.Validate) SyncingHandler {
	return &syncingHandler{syncingUC: syncingUseCase, validator: appValidator}
}

type SyncingHandler interface {
	GetAllSyncing() fiber.Handler
	DeleteSyncing() fiber.Handler
}
