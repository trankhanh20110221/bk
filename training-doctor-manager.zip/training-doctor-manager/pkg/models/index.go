package models

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

const (
	CollectionIndex = "indexes"
)

type Index struct {
	CreatedAt  time.Time          `bson:"created_at"`
	UpdatedAt  time.Time          `bson:"updated_at"`
	Options    IndexOption        `bson:"options"`
	Collection string             `bson:"collection"`
	Name       string             `bson:"name"`
	KeyString  string             `bson:"key_string"`
	Keys       []IndexKey         `bson:"keys"`
	ID         primitive.ObjectID `bson:"_id,omitempty"`
	DatabaseID primitive.ObjectID `bson:"database_id"`
}

type IndexOption struct {
	ExpireAfterSeconds *int32 `bson:"expire_after_seconds"`
	IsUnique           bool   `bson:"is_unique"`
}

type IndexKey struct {
	Field string `bson:"field"`
	Value int32  `bson:"value"`
}
