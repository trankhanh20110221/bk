package models

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

const (
	CollectionAuthToken = "tokens"
)

type AuthToken struct {
	ExpireAt  time.Time          `bson:"expire_at"`
	CreatedAt time.Time          `bson:"created_at"`
	UpdatedAt time.Time          `bson:"updated_at"`
	ID        primitive.ObjectID `bson:"_id,omitempty"`
	AccountId primitive.ObjectID `bson:"account_id"`
}
