package models

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

const (
	CollectionDatabase = "databases"
)

type Database struct {
	CreatedAt   time.Time          `bson:"created_at" json:"created_at"`
	UpdatedAt   time.Time          `bson:"updated_at" json:"updated_at"`
	Name        string             `bson:"name" json:"name"`
	Description string             `bson:"description" json:"description"`
	Uri         string             `bson:"uri" json:"uri"`
	DBName      string             `bson:"db_name" json:"db_name"`
	ID          primitive.ObjectID `bson:"_id,omitempty" json:"id"`
}
