package models

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

const (
	CollectionSyncing = "syncing"
)

type Syncing struct {
	CreatedAt      time.Time          `bson:"created_at"`
	UpdatedAt      time.Time          `bson:"updated_at"`
	CollectionName string             `bson:"collection_name"`
	Error          string             `bson:"error"`
	Type           int                `bson:"type"`
	TotalTasks     int                `bson:"total_tasks"`
	CompletedTasks int                `bson:"completed_tasks"`
	ID             primitive.ObjectID `bson:"_id,omitempty"`
	UserID         primitive.ObjectID `bson:"user_id"`
	DatabaseID     primitive.ObjectID `bson:"database_id"`
}
