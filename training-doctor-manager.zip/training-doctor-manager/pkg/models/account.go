package models

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

const (
	CollectionAccount = "accounts"
)

type Account struct {
	CreatedAt    time.Time          `bson:"created_at"`
	UpdatedAt    time.Time          `bson:"updated_at"`
	Username     string             `bson:"username"`
	FirstName    string             `bson:"first_name"`
	LastName     string             `bson:"last_name"`
	Avatar       string             `bson:"avatar"`
	Phone        string             `bson:"phone"`
	Email        string             `bson:"email"`
	PasswordHash string             `bson:"password_hash"`
	ID           primitive.ObjectID `bson:"_id,omitempty"`
}
