package middleware

import (
	"training-doctor-manager/common/config"
	"training-doctor-manager/pkg/repository"
)

type MWManager struct {
	cfg       *config.Config
	TokenRepo repository.AuthTokenRepository
}

func NewMiddlewareManager(cfg *config.Config, accountRepo repository.AccountRepository, tokenRepo repository.AuthTokenRepository) *MWManager {
	return &MWManager{cfg: cfg, TokenRepo: tokenRepo}
}
