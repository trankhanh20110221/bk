package repository

import (
	"context"
	"errors"
	"net/http"
	"time"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"training-doctor-manager/common"
	"training-doctor-manager/common/logging"
	"training-doctor-manager/pkg/account/model"
)

var (
	logger = logging.GetLogger()
)

type accountRepository struct {
	coll *mongo.Collection
}

type AccountRepository interface {
	CreateAccount(c context.Context, user model.Account) (*model.Account, error)
	UpdateAccountByID(ctx context.Context, accountID primitive.ObjectID, data model.UpdateAccountRequest) error
	GetByAccountID(c context.Context, accountId primitive.ObjectID) (*model.Account, error)
	GetByEmail(c context.Context, email string) (*model.Account, error)
}

func NewAccountRepository(db *mongo.Database) AccountRepository {
	return &accountRepository{
		coll: db.Collection(model.CollectionAccount),
	}
}

func (repo *accountRepository) CreateAccount(c context.Context, user model.Account) (*model.Account, error) {
	currentTime := time.Now()
	user.CreatedAt = currentTime
	user.UpdatedAt = currentTime
	result, err := repo.coll.InsertOne(c, user)
	if err != nil {
		logger.Error().Err(err).Str("function", "CreateAccount").Str("functionInline", "repo.coll.InsertOne").Msg("accountRepository")
		if mongo.IsDuplicateKeyError(err) {
			return nil, common.NewErrorResponse(http.StatusConflict, err, "An account with this email or this username is already existed", "ErrAccountIsExisted")
		}
		return nil, common.NewErrorResponse(http.StatusInternalServerError, err, "Cannot create account", "ErrCannotCreateAccount")
	}
	user.ID = result.InsertedID.(primitive.ObjectID)
	return &user, nil
}

func (repo *accountRepository) GetByEmail(c context.Context, email string) (*model.Account, error) {
	var user *model.Account
	if err := repo.coll.FindOne(c, bson.M{"email": email}).Decode(&user); err != nil {
		logger.Error().Err(err).Str("function", "GetByEmail").Str("functionInline", "repo.coll.FindOne").Msg("accountRepository")
		if errors.Is(err, mongo.ErrNoDocuments) {
			return nil, common.NewErrorResponse(http.StatusNotFound, err, "Account does not exist", "ErrAccountNotFound")
		}
		return nil, common.NewErrorResponse(http.StatusInternalServerError, err, "Cannot get account", "ErrCannotGetAccount")
	}
	return user, nil
}

func (repo *accountRepository) GetByAccountID(c context.Context, accountId primitive.ObjectID) (*model.Account, error) {
	var user *model.Account
	if err := repo.coll.FindOne(c, bson.M{"_id": accountId}).Decode(&user); err != nil {
		logger.Error().Err(err).Str("function", "GetByAccountID").Str("functionInline", "repo.coll.FindOne").Msg("accountRepository")
		if errors.Is(err, mongo.ErrNoDocuments) {
			return nil, common.NewErrorResponse(http.StatusNotFound, err, "Account does not exist", "ErrAccountNotFound")
		}
		return nil, common.NewErrorResponse(http.StatusInternalServerError, err, "Cannot get account", "ErrCannotGetAccount")
	}
	return user, nil
}

func (repo *accountRepository) UpdateAccountByID(ctx context.Context, accountID primitive.ObjectID, data model.UpdateAccountRequest) error {
	_, err := repo.coll.UpdateOne(ctx,
		bson.M{"_id": accountID},
		bson.D{{"$set", bson.D{
			{"first_name", data.FirstName},
			{"last_name", data.LastName},
			{"phone", data.Phone},
			{"avatar", data.Avatar},
			{"updated_at", time.Now()},
		}}})
	if err != nil {
		logger.Error().Err(err).Str("function", "UpdateAccountByID").Str("functionInline", "repo.coll.UpdateOne").Msg("accountRepository")
		return common.NewErrorResponse(http.StatusInternalServerError, err, "Cannot update account", "ErrCannotUpdateAccount")
	}
	return nil
}
