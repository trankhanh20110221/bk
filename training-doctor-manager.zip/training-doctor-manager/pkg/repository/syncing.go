package repository

import (
	"context"
	"net/http"
	"time"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"training-doctor-manager/common/response"
	"training-doctor-manager/pkg/models"
)

type SyncingRepository interface {
	GetSyncing(ctx context.Context) ([]models.Syncing, error)
	UpdateErrorByID(ctx context.Context, syncingID primitive.ObjectID, errMsg string) error
	UpdateIncreaseCompletedTaskByID(ctx context.Context, syncingID primitive.ObjectID, amount int) error
	CreateSyncing(ctx context.Context, data models.Syncing) (*models.Syncing, error)
	DeleteSyncingByID(ctx context.Context, syncingID primitive.ObjectID) error
}

func NewSyncingRepository(db *mongo.Database) SyncingRepository {
	return &syncingRepository{
		coll: db.Collection(models.CollectionSyncing),
	}
}

type syncingRepository struct {
	coll *mongo.Collection
}

func (rp *syncingRepository) CreateSyncing(ctx context.Context, data models.Syncing) (*models.Syncing, error) {
	currentTime := time.Now()
	data.CreatedAt = currentTime
	data.UpdatedAt = currentTime
	res, err := rp.coll.InsertOne(ctx, data)
	if err != nil {
		logger.Error().Err(err).Str("function", "CreateSyncing").Str("functionInline", "rp.coll.InsertOne").Msg("syncingRepository")
		return nil, response.NewErrorResponse(http.StatusInternalServerError, err, "Can not create Syncing record", "ErrCannotCreateSyncing")
	}
	data.ID = res.InsertedID.(primitive.ObjectID)
	return &data, err
}

func (rp *syncingRepository) DeleteSyncingByID(ctx context.Context, syncingID primitive.ObjectID) error {
	if _, err := rp.coll.DeleteOne(ctx, bson.M{"_id": syncingID}); err != nil {
		logger.Error().Err(err).Str("function", "DeleteSyncingByID").Str("functionInline", "rp.coll.DeleteOne").Msg("syncingRepository")
		return response.NewErrorResponse(http.StatusInternalServerError, err, "Cannot delete syncing", "ErrCannotDeleteSyncing")
	}
	return nil
}

func (rp *syncingRepository) GetSyncing(ctx context.Context) ([]models.Syncing, error) {
	opts := options.Find().SetSort(bson.D{{"_id", -1}})
	cursor, err := rp.coll.Find(ctx, opts)
	if err != nil {
		logger.Error().Err(err).Str("function", "GetSyncing").Str("functionInline", "rp.coll.Find").Msg("syncingRepository")
		return nil, response.NewErrorResponse(http.StatusInternalServerError, err, "Cannot get syncing", "ErrCannotGetSyncing")
	}
	var result []models.Syncing
	if err = cursor.All(ctx, &result); err != nil {
		logger.Error().Err(err).Str("function", "GetSyncing").Str("functionInline", "cursor.All").Msg("syncingRepository")
		return nil, response.NewErrorResponse(http.StatusInternalServerError, err, "Cannot get syncing", "ErrCannotGetSyncing")
	}
	return result, nil
}

func (rp *syncingRepository) UpdateErrorByID(ctx context.Context, syncingID primitive.ObjectID, errMsg string) error {
	if _, err := rp.coll.UpdateOne(ctx,
		bson.M{"_id": syncingID},
		bson.D{{"$set", bson.D{
			{"error", errMsg},
		}}}); err != nil {
		logger.Error().Err(err).Str("function", "UpdateErrorByID").Str("functionInline", "rp.coll.UpdateOne").Msg("syncingRepository")
	}
	return nil
}

func (rp *syncingRepository) UpdateIncreaseCompletedTaskByID(ctx context.Context, syncingID primitive.ObjectID, amount int) error {
	if _, err := rp.coll.UpdateOne(ctx,
		bson.M{"_id": syncingID},
		bson.D{{"$inc", bson.D{
			{"completed_tasks", amount},
		}}}); err != nil {
		logger.Error().Err(err).Str("function", "UpdateIncreaseCompletedTaskByID").Str("functionInline", "rp.coll.UpdateOne").Msg("syncingRepository")
	}
	return nil
}
