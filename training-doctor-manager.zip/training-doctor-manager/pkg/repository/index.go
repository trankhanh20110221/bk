package repository

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"time"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"training-doctor-manager/common/constant"
	"training-doctor-manager/common/request"
	"training-doctor-manager/common/response"
	"training-doctor-manager/pkg/models"
	"training-doctor-manager/pkg/parameters"
)

type IndexRepository interface {
	GetIndexByID(ctx context.Context, indexID primitive.ObjectID) (*models.Index, error)
	GetIndexByCollection(ctx context.Context, collection string) (*models.Index, error)
	GetIndexByCollectionAndDatabaseID(ctx context.Context, collection string, databaseID primitive.ObjectID) (*models.Index, error)
	GetIndexesByDatabaseIDAndCollection(ctx context.Context, databaseID primitive.ObjectID, collection string) ([]*models.Index, error)
	CreateIndex(ctx context.Context, data models.Index) (*models.Index, error)
	UpdateIndexByID(ctx context.Context, indexID primitive.ObjectID, data models.Index) error
	DeleteIndexByID(ctx context.Context, indexID primitive.ObjectID) error
	DeleteIndexesByCollection(ctx context.Context, collection string) error
	DeleteIndexesByDatabaseID(ctx context.Context, databaseID primitive.ObjectID) error
	DeleteIndexesByDatabaseIDs(ctx context.Context, databaseIDs []primitive.ObjectID) error
	DeleteIndexesByKeyStrings(ctx context.Context, keyStrings []string) error
	DeleteIndexesByIDs(ctx context.Context, indexesIDs []primitive.ObjectID) error
	SyncIndexesByCollection(ctx context.Context, dbClient *mongo.Database,
		databaseID primitive.ObjectID, collectionName string,
		missingIndexes, extraIndexes []parameters.IndexCompare,
		optMissing, optExtra int,
	) error
	GetCollectionsByDatabaseID(ctx context.Context, databaseID primitive.ObjectID) ([]*parameters.CollectionResponse, error)
	ListCollections(ctx context.Context, databaseID primitive.ObjectID, paging *request.Paging, filter *parameters.FilterCollection) ([]*parameters.CollectionResponse, error)
	CreateCollection(ctx context.Context, databaseID primitive.ObjectID, collectionName string) error
	GetIndexesFromClient(ctx context.Context, dbClient *mongo.Database, collectionName string) ([]*models.Index, error)
}

func NewIndexRepository(db *mongo.Database) IndexRepository {
	return &indexRepository{
		coll: db.Collection(models.CollectionIndex),
	}
}

type indexRepository struct {
	coll *mongo.Collection
}

func (repo *indexRepository) CreateCollection(ctx context.Context, databaseID primitive.ObjectID, collectionName string) error {
	currentTime := time.Now()
	data := models.Index{
		DatabaseID: databaseID,
		Collection: collectionName,
		Name:       "_id_",
		Keys: []models.IndexKey{{
			Field: "_id",
			Value: 1,
		}},
		KeyString: "_id_1",
		CreatedAt: currentTime,
		UpdatedAt: currentTime,
	}

	if _, err := repo.coll.InsertOne(ctx, data); err != nil {
		logger.Error().Err(err).Str("function", "CreateCollection").Str("functionInline", "repo.coll.InsertOne").Msg("indexRepository")
		return response.NewErrorResponse(http.StatusInternalServerError, err, "Cannot create collection", "ErrCannotCreateCollection")
	}
	return nil
}

func (repo *indexRepository) CreateIndex(ctx context.Context, data models.Index) (*models.Index, error) {
	currentTime := time.Now()
	data.CreatedAt = currentTime
	data.UpdatedAt = currentTime
	result, err := repo.coll.InsertOne(ctx, data)
	if err != nil {
		logger.Error().Err(err).Str("function", "CreateIndex").Str("functionInline", "repo.coll.InsertOne").Msg("indexRepository")
		if mongo.IsDuplicateKeyError(err) {
			return nil, response.NewErrorResponse(http.StatusConflict, err, "Constraint violated: "+response.ParseIndexFromMessage(err.Error()), "ErrIndexConflict")
		}
		return nil, response.NewErrorResponse(http.StatusInternalServerError, err, "Cannot create index", "ErrCannotCreateIndex")
	}

	data.ID = result.InsertedID.(primitive.ObjectID)
	return &data, err
}

func (repo *indexRepository) CreateIndexes(ctx context.Context, data []models.Index) error {
	documents := make([]interface{}, 0)
	for _, index := range data {
		documents = append(documents, index)
	}

	if _, err := repo.coll.InsertMany(ctx, documents); err != nil {
		logger.Error().Err(err).Str("function", "CreateIndexes").Str("functionInline", "repo.coll.InsertMany").Msg("indexRepository")
		return err
	}
	return nil
}

func (repo *indexRepository) DeleteIndexByID(ctx context.Context, indexID primitive.ObjectID) error {
	if _, err := repo.coll.DeleteOne(ctx, bson.M{"_id": indexID}); err != nil {
		logger.Error().Err(err).Str("function", "DeleteIndexByID").Str("functionInline", "repo.coll.DeleteOne").Msg("indexRepository")
		return response.NewErrorResponse(http.StatusInternalServerError, err, "Cannot delete index", "ErrCannotDeleteIndex")
	}
	return nil
}

func (repo *indexRepository) DeleteIndexesByCollection(ctx context.Context, collection string) error {
	if _, err := repo.coll.DeleteMany(ctx, bson.M{"collection": collection}); err != nil {
		logger.Error().Err(err).Str("function", "DeleteIndexesByCollection").Str("functionInline", "repo.coll.DeleteMany").Msg("indexRepository")
		return response.NewErrorResponse(http.StatusInternalServerError, err, "Cannot delete indexes", "ErrCannotDeleteIndexes")
	}
	return nil
}

func (repo *indexRepository) DeleteIndexesByDatabaseID(ctx context.Context, databaseID primitive.ObjectID) error {
	if _, err := repo.coll.DeleteMany(ctx, bson.M{"database_id": databaseID}); err != nil {
		logger.Error().Err(err).Str("function", "DeleteIndexesByDatabaseID").Str("functionInline", "repo.coll.DeleteMany").Msg("indexRepository")
		return response.NewErrorResponse(http.StatusInternalServerError, err, "Cannot delete indexes", "ErrCannotDeleteIndexes")
	}
	return nil
}

func (repo *indexRepository) DeleteIndexesByDatabaseIDs(ctx context.Context, databaseIDs []primitive.ObjectID) error {
	if _, err := repo.coll.DeleteMany(ctx, bson.M{"database_id": bson.M{"$in": databaseIDs}}); err != nil {
		logger.Error().Err(err).Str("function", "DeleteIndexesByDatabaseIDs").Str("functionInline", "repo.coll.DeleteMany").Msg("indexRepository")
		return response.NewErrorResponse(http.StatusInternalServerError, err, "Cannot delete indexes", "ErrCannotDeleteIndexes")
	}
	return nil
}

func (repo *indexRepository) DeleteIndexesByKeyStrings(ctx context.Context, keyStrings []string) error {
	if _, err := repo.coll.DeleteMany(ctx, bson.M{"key_string": bson.M{"$in": keyStrings}}); err != nil {
		logger.Error().Err(err).Str("function", "DeleteIndexesByKeyStrings").Str("functionInline", "repo.coll.DeleteMany").Msg("indexRepository")
		return response.NewErrorResponse(http.StatusInternalServerError, err, "Cannot delete indexes", "ErrCannotDeleteIndexes")
	}
	return nil
}

func (repo *indexRepository) DeleteIndexesByIDs(ctx context.Context, indexesIDs []primitive.ObjectID) error {
	if _, err := repo.coll.DeleteMany(ctx, bson.M{"_id": bson.M{"$in": indexesIDs}}); err != nil {
		logger.Error().Err(err).Str("function", "DeleteIndexesByIDs").Str("functionInline", "repo.coll.DeleteMany").Msg("indexRepository")
		return response.NewErrorResponse(http.StatusInternalServerError, err, "Cannot delete indexes", "ErrCannotDeleteIndexes")
	}
	return nil
}

func (repo *indexRepository) GetCollectionsByDatabaseID(ctx context.Context, databaseID primitive.ObjectID) ([]*parameters.CollectionResponse, error) {
	var result []*parameters.CollectionResponse
	cursor, err := repo.coll.Aggregate(ctx, mongo.Pipeline{
		{{"$match", bson.M{"database_id": databaseID}}},
		{{"$group", bson.M{"_id": "$collection"}}},
		{{"$project", bson.M{"_id": 0, "collection": "$_id"}}},
		{{"$sort", bson.M{"_id": -1}}},
	})
	if err != nil {
		logger.Error().Err(err).Str("function", "GetCollectionsByDatabaseID").Str("functionInline", "repo.coll.Aggregate").Msg("indexRepository")
		return nil, response.NewErrorResponse(http.StatusInternalServerError, err, "Cannot list collections", "ErrCannotListCollection")
	}
	if err = cursor.All(ctx, &result); err != nil {
		logger.Error().Err(err).Str("function", "GetCollectionsByDatabaseID").Str("functionInline", "cursor.All").Msg("indexRepository")
		return nil, response.NewErrorResponse(http.StatusInternalServerError, err, "Cannot list collections", "ErrCannotListCollection")
	}

	return result, nil
}

func (repo *indexRepository) GetIndexByID(ctx context.Context, indexID primitive.ObjectID) (*models.Index, error) {
	var result models.Index
	if err := repo.coll.FindOne(ctx, bson.M{"_id": indexID}).Decode(&result); err != nil {
		logger.Error().Err(err).Str("function", "GetIndexByID").Str("functionInline", "repo.coll.FindOne").Msg("indexRepository")
		if errors.Is(err, mongo.ErrNoDocuments) {
			return nil, response.NewErrorResponse(http.StatusNotFound, err, "Index not found", "IndexNotFound")
		}
		return nil, response.NewErrorResponse(http.StatusInternalServerError, err, "Cannot get index", "ErrCannotGetIndex")
	}
	return &result, nil
}

func (repo *indexRepository) GetIndexByCollection(ctx context.Context, collection string) (*models.Index, error) {
	var result models.Index
	if err := repo.coll.FindOne(ctx, bson.M{"collection": collection}).Decode(&result); err != nil {
		logger.Error().Err(err).Str("function", "GetIndexByCollection").Str("functionInline", "repo.coll.FindOne").Msg("indexRepository")
		return nil, response.NewErrorResponse(http.StatusNotFound, errors.New("error collection not found"), fmt.Sprintf("There is no colleciton with the name `%s` !", collection), "ErrCollectionNotFound")
	}
	return &result, nil
}

func (repo *indexRepository) GetIndexByCollectionAndDatabaseID(ctx context.Context, collection string, databaseID primitive.ObjectID) (*models.Index, error) {
	var result models.Index
	if err := repo.coll.FindOne(ctx, bson.M{"collection": collection, "database_id": databaseID}).Decode(&result); err != nil {
		logger.Error().Err(err).Str("function", "GetIndexByCollectionAndDatabaseID").Str("functionInline", "repo.coll.FindOne").Msg("indexRepository")
		return nil, response.NewErrorResponse(http.StatusConflict, errors.New("error duplicated"), fmt.Sprintf("A colleciton with the name `%s` is existed!", collection), "ErrCollectionDuplicated")
	}
	return &result, nil
}

func (repo *indexRepository) GetIndexesByDatabaseIDAndCollection(ctx context.Context, databaseID primitive.ObjectID, collection string) ([]*models.Index, error) {
	var result []*models.Index
	cursor, err := repo.coll.Find(ctx,
		bson.M{"database_id": databaseID, "collection": collection, "name": bson.M{"$ne": "_id_"}},
		options.Find().SetSort(bson.D{{"_id", -1}}))
	if err != nil {
		logger.Error().Err(err).Str("function", "GetIndexesByDatabaseIDAndCollection").Str("functionInline", "repo.coll.Find").Msg("indexRepository")
		return nil, response.NewErrorResponse(http.StatusInternalServerError, err, "Cannot list indexes", "ErrCannotListIndex")
	}
	if err = cursor.All(ctx, &result); err != nil {
		return nil, response.NewErrorResponse(http.StatusInternalServerError, err, "Cannot list indexes", "ErrCannotListIndex")
	}
	return result, nil
}

func (repo *indexRepository) GetIndexesFromClient(ctx context.Context, dbClient *mongo.Database, collectionName string) ([]*models.Index, error) {
	cursor, err := dbClient.Collection(collectionName).Indexes().List(ctx)
	if err != nil {
		logger.Error().Err(err).Str("function", "GetIndexesFromClient").Str("functionInline", "dbClient.Collection(collectionName).Indexes().List").Msg("indexRepository")
		return nil, response.NewErrorResponse(http.StatusInternalServerError, err, err.Error(), "ErrCannotListIndex")
	}

	var indexes []primitive.D
	if err = cursor.All(ctx, &indexes); err != nil {
		logger.Error().Err(err).Str("function", "GetIndexesFromClient").Str("functionInline", "cursor.All").Msg("indexRepository")
		return nil, response.NewErrorResponse(http.StatusInternalServerError, err, err.Error(), "ErrCannotListIndex")
	}
	indexModels := make([]*models.Index, len(indexes))
	for key, value := range indexes {
		indexModels[key] = parameters.ToIndexModel(value)
		indexModels[key].Collection = collectionName
	}

	return indexModels, nil
}

func (repo *indexRepository) ListCollections(ctx context.Context, databaseID primitive.ObjectID, paging *request.Paging, filter *parameters.FilterCollection) ([]*parameters.CollectionResponse, error) {
	var result []*parameters.CollectionResponse
	filterQuery := bson.D{}
	if filter != nil {
		var queries []bson.D
		if v := filter.CollectionName; v != "" {
			queries = append(queries, bson.D{{
				"collection", primitive.Regex{Pattern: v, Options: "i"},
			}})
		}
		if len(queries) > 0 {
			filterQuery = bson.D{{"$or", queries}}
		}
	}

	pipeline := mongo.Pipeline{
		{{"$match", bson.M{"database_id": databaseID}}},
		{{"$match", filterQuery}},
		{{"$group", bson.M{"_id": "$collection"}}},
		{{"$project", bson.M{"_id": 0, "collection": "$_id"}}},
		{{"$skip", (paging.Page - 1) * paging.Limit}},
		{{"$limit", paging.Limit}},
		{{"$sort", bson.M{"_id": -1}}},
	}
	countPipeline := mongo.Pipeline{
		{{"$match", bson.M{"database_id": databaseID}}},
		{{"$match", filterQuery}},
		{{"$group", bson.M{"_id": "$collection"}}},
		{{"$count", "total"}},
	}

	cursor, err := repo.coll.Aggregate(ctx, pipeline)
	if err != nil {
		logger.Error().Err(err).Str("function", "ListCollections").Str("functionInline", "repo.coll.Aggregate(ctx, pipeline)").Msg("indexRepository")
		return nil, response.NewErrorResponse(http.StatusInternalServerError, err, "Cannot list collections", "ErrCannotListCollections")
	}
	if err = cursor.All(ctx, &result); err != nil {
		logger.Error().Err(err).Str("function", "ListCollections").Str("functionInline", "cursor.All").Msg("indexRepository")
		return nil, response.NewErrorResponse(http.StatusInternalServerError, err, "Cannot list collections", "ErrCannotListCollections")
	}

	var countResult struct {
		Total int64 `bson:"total"`
	}
	countCursor, err := repo.coll.Aggregate(ctx, countPipeline)
	if err != nil {
		logger.Error().Err(err).Str("function", "ListCollections").Str("functionInline", "repo.coll.Aggregate(ctx, countPipeline)").Msg("indexRepository")
		return result, response.NewErrorResponse(http.StatusInternalServerError, err, "Cannot list collections", "ErrCannotListCollections")
	}
	defer func() {
		if curErr := countCursor.Close(ctx); curErr != nil {
			logger.Error().Err(curErr).Str("function", "ListCollections").Str("functionInline", "countCursor.Close").Msg("indexRepository")
		}
	}()
	if countCursor.Next(ctx) {
		if err = countCursor.Decode(&countResult); err != nil {
			logger.Error().Err(err).Str("function", "ListCollections").Str("functionInline", "countCursor.Decode").Msg("indexRepository")
			return result, response.NewErrorResponse(http.StatusInternalServerError, err, "Cannot list collections", "ErrCannotListCollections")
		}
	}
	paging.Total = countResult.Total

	for i, coll := range result {
		indexCountPipeline := mongo.Pipeline{
			{{"$match", bson.M{"database_id": databaseID, "collection": coll.CollectionName, "name": bson.M{"$ne": "_id_"}}}},
			{{"$count", "total_indexes"}},
		}
		var indexCountResult struct {
			TotalIndexes int `bson:"total_indexes"`
		}

		indexCountCursor, err := repo.coll.Aggregate(ctx, indexCountPipeline)
		if err != nil {
			logger.Error().Err(err).Str("function", "ListCollections").Str("functionInline", "repo.coll.Aggregate(ctx, indexCountPipeline)").Msg("indexRepository")
			return result, response.NewErrorResponse(http.StatusInternalServerError, err, "Cannot list collections", "ErrCannotListCollections")
		}
		if indexCountCursor.Next(ctx) {
			if err = indexCountCursor.Decode(&indexCountResult); err != nil {
				logger.Error().Err(err).Str("function", "ListCollections").Str("functionInline", "indexCountCursor.Decode").Msg("indexRepository")
				return result, response.NewErrorResponse(http.StatusInternalServerError, err, "Cannot list collections", "ErrCannotListCollections")
			}
		}

		result[i].TotalIndexes = indexCountResult.TotalIndexes
		if err = indexCountCursor.Close(ctx); err != nil {
			logger.Error().Err(err).Str("function", "ListCollections").Str("functionInline", "indexCountCursor.Close").Msg("indexRepository")
			return result, response.NewErrorResponse(http.StatusInternalServerError, err, "Cannot list collections", "ErrCannotListCollections")
		}
	}

	return result, nil
}

func (repo *indexRepository) SyncIndexesByCollection(
	ctx context.Context, dbClient *mongo.Database,
	databaseID primitive.ObjectID, collectionName string,
	missingIndexes, extraIndexes []parameters.IndexCompare,
	optMissing, optExtra int,
) error {
	coll := dbClient.Collection(collectionName)

	if len(extraIndexes) > 0 {
		if optExtra == constant.OptionSyncForward {
			for _, index := range extraIndexes {
				if _, err := coll.Indexes().DropOne(ctx, index.Name); err != nil {
					var convertErr mongo.CommandError
					if errors.As(err, &convertErr) {
						if !convertErr.HasErrorCode(constant.MongoErrNamespaceNotFound) || !convertErr.HasErrorCode(constant.MongoErrIndexNotFound) {
							logger.Error().Err(err).Str("function", "SyncIndexesByCollection").Str("functionInline", "coll.Indexes().DropOne").Msg("indexRepository")
							return response.NewErrorResponse(http.StatusInternalServerError, err, err.Error(), "ErrCannotSyncIndexes")
						}
					}
				}
			}
		} else if optExtra == constant.OptionSyncBack {
			indexModels := parameters.ToIndexModelArr(extraIndexes, databaseID, collectionName)
			err := repo.CreateIndexes(ctx, indexModels)
			if err != nil {
				logger.Error().Err(err).Str("function", "SyncIndexesByCollection").Str("functionInline", "repo.CreateIndexes").Msg("indexRepository")
				return response.NewErrorResponse(http.StatusInternalServerError, err, err.Error(), "ErrCannotSyncIndexes")
			}
		}
	}

	if len(missingIndexes) > 0 {
		if optMissing == constant.OptionSyncForward {
			indexes := parameters.ToMongoIndexArr(missingIndexes)
			opt := options.CreateIndexes()
			if _, err := coll.Indexes().CreateMany(ctx, indexes, opt); err != nil {
				logger.Error().Err(err).Str("function", "SyncIndexesByCollection").Str("functionInline", "coll.Indexes().CreateMany").Msg("indexRepository")
				return response.NewErrorResponse(http.StatusInternalServerError, err, err.Error(), "ErrCannotSyncIndexes")
			}
		} else if optMissing == constant.OptionSyncBack {
			keyStrings := make([]string, len(missingIndexes))
			for i := range missingIndexes {
				keyStrings[i] = missingIndexes[i].KeyString
			}

			if err := repo.DeleteIndexesByKeyStrings(ctx, keyStrings); err != nil {
				logger.Error().Err(err).Str("function", "SyncIndexesByCollection").Str("functionInline", "repo.DeleteIndexesByKeyStrings").Msg("indexRepository")
				return response.NewErrorResponse(http.StatusInternalServerError, err, err.Error(), "ErrCannotSyncIndexes")
			}
		}
	}

	return nil
}

func (repo *indexRepository) UpdateIndexByID(ctx context.Context, indexID primitive.ObjectID, data models.Index) error {
	if _, err := repo.coll.UpdateOne(ctx,
		bson.M{"_id": indexID},
		bson.D{{"$set", bson.D{
			{"database_id", data.DatabaseID},
			{"collection", data.Collection},
			{"name", data.Name},
			{"keys", data.Keys},
			{"key_string", data.KeyString},
			{"options", data.Options},
			{"created_at", data.CreatedAt},
			{"updated_at", data.UpdatedAt},
		}}}); err != nil {
		logger.Error().Err(err).Str("function", "UpdateIndexByID").Str("functionInline", "repo.coll.UpdateOne").Msg("indexRepository")
		if mongo.IsDuplicateKeyError(err) {
			return response.NewErrorResponse(http.StatusConflict, err, "Constraint violated: "+response.ParseIndexFromMessage(err.Error()), "ErrIndexConflict")
		}
		return response.NewErrorResponse(http.StatusInternalServerError, err, "Cannot update index", "ErrCannotUpdateIndex")
	}
	return nil
}
