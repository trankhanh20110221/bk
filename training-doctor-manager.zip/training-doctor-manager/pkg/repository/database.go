package repository

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"time"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"training-doctor-manager/common"
	"training-doctor-manager/pkg/database/model"
)

type DatabaseRepository interface {
	CreateDatabase(ctx context.Context, data model.Database) (*model.Database, error)
	GetDatabaseByID(ctx context.Context, databaseID primitive.ObjectID) (*model.Database, error)
	GetDatabases(ctx context.Context, paging *common.Paging, filter *model.FilterDatabase) ([]model.Database, error)
	DeleteDatabaseByID(ctx context.Context, databaseID primitive.ObjectID) error
	UpdateDatabaseByID(ctx context.Context, databaseID primitive.ObjectID, data model.Database) error
	DeleteDatabasesByIDs(ctx context.Context, databaseIDs []primitive.ObjectID) error
}

func NewDatabaseRepository(db *mongo.Database) DatabaseRepository {
	return &databaseRepository{
		coll: db.Collection(model.CollectionDatabase),
	}
}

type databaseRepository struct {
	coll *mongo.Collection
}

func (repo *databaseRepository) CreateDatabase(ctx context.Context, data model.Database) (*model.Database, error) {
	currentTime := time.Now()
	data.CreatedAt = currentTime
	data.UpdatedAt = currentTime
	result, err := repo.coll.InsertOne(ctx, data)
	if err != nil {
		logger.Error().Err(err).Str("function", "CreateDatabase").Str("functionInline", "repo.coll.InsertOne").Msg("databaseRepository")
		if mongo.IsDuplicateKeyError(err) {
			return nil, common.NewErrorResponse(http.StatusConflict, err, fmt.Sprintf("A database with the name `%s` is existed!", data.Name), "ErrDatabaseDuplicated")
		}
		return nil, common.NewErrorResponse(http.StatusInternalServerError, err, "Cannot create database", "ErrCannotCreateDatabase")
	}

	data.ID = result.InsertedID.(primitive.ObjectID)
	return &data, nil
}

func (repo *databaseRepository) DeleteDatabaseByID(ctx context.Context, databaseID primitive.ObjectID) error {
	if _, err := repo.coll.DeleteOne(ctx, bson.M{"_id": databaseID}); err != nil {
		logger.Error().Err(err).Str("function", "DeleteDatabaseByID").Str("functionInline", "repo.coll.DeleteOne").Msg("databaseRepository")
		return common.NewErrorResponse(http.StatusInternalServerError, err, "Cannot delete database", "ErrCannotDeleteDatabase")
	}
	return nil
}

func (repo *databaseRepository) DeleteDatabasesByIDs(ctx context.Context, databaseIDs []primitive.ObjectID) error {
	if _, err := repo.coll.DeleteMany(ctx, bson.M{"_id": bson.M{"$in": databaseIDs}}); err != nil {
		logger.Error().Err(err).Str("function", "DeleteDatabasesByIDs").Str("functionInline", "repo.coll.DeleteMany").Msg("databaseRepository")
		return common.NewErrorResponse(http.StatusInternalServerError, err, "Cannot delete database", "ErrCannotDeleteDatabase")
	}
	return nil
}

func (repo *databaseRepository) GetDatabases(
	ctx context.Context,
	paging *common.Paging,
	filter *model.FilterDatabase,
) ([]model.Database, error) {
	var result []model.Database
	filterQuery := bson.D{}
	var queries []bson.D
	if filter != nil {
		if v := filter.Name; v != "" {
			queries = append(queries, bson.D{{
				"name", primitive.Regex{Pattern: v, Options: "i"},
			}})
		}
		if len(queries) > 0 {
			filterQuery = bson.D{{"$or", queries}}
		}
	}

	countOptions := options.Count().SetHint("_id_")
	total, err := repo.coll.CountDocuments(ctx, filterQuery, countOptions)
	if err != nil {
		logger.Error().Err(err).Str("function", "GetDatabases").Str("functionInline", "repo.coll.CountDocuments").Msg("databaseRepository")
		return nil, common.NewErrorResponse(http.StatusInternalServerError, err, "Cannot get database", "ErrCannotGetDatabases")
	}
	paging.Total = total

	findOptions := options.Find()
	findOptions.SetSkip(int64((paging.Page - 1) * paging.Limit))
	findOptions.SetLimit(int64(paging.Limit))
	findOptions.SetSort(bson.D{{"_id", -1}})

	cursor, err := repo.coll.Find(ctx, filterQuery, findOptions)
	if err != nil {
		logger.Error().Err(err).Str("function", "GetDatabases").Str("functionInline", "repo.coll.Find").Msg("databaseRepository")
		return nil, common.NewErrorResponse(http.StatusInternalServerError, err, "Cannot get database", "ErrCannotGetDatabases")
	}
	if err = cursor.All(ctx, &result); err != nil {
		logger.Error().Err(err).Str("function", "GetDatabases").Str("functionInline", "cursor.All").Msg("databaseRepository")
		return nil, common.NewErrorResponse(http.StatusInternalServerError, err, "Cannot get database", "ErrCannotGetDatabases")
	}
	return result, nil
}

func (repo *databaseRepository) GetDatabaseByID(ctx context.Context, databaseID primitive.ObjectID) (*model.Database, error) {
	var result model.Database
	if err := repo.coll.FindOne(ctx, bson.M{"_id": databaseID}).Decode(&result); err != nil {
		logger.Error().Err(err).Str("function", "GetDatabaseByID").Str("functionInline", "repo.coll.FindOne").Msg("databaseRepository")
		if errors.Is(err, mongo.ErrNoDocuments) {
			return nil, common.NewErrorResponse(http.StatusNotFound, err, "Database not found", "ErrDatabaseNotFound")
		}
		return nil, common.NewErrorResponse(http.StatusInternalServerError, err, "Cannot get database", "ErrCannotGetDatabase")
	}

	return &result, nil
}

func (repo *databaseRepository) UpdateDatabaseByID(ctx context.Context, databaseID primitive.ObjectID, data model.Database) error {
	if _, err := repo.coll.UpdateOne(ctx,
		bson.M{"_id": databaseID},
		bson.D{{"$set", bson.D{
			{"name", data.Name},
			{"description", data.Description},
			{"uri", data.Uri},
			{"db_name", data.DBName},
			{"updated_at", data.UpdatedAt},
		}}}); err != nil {
		logger.Error().Err(err).Str("function", "UpdateDatabaseByID").Str("functionInline", "repo.coll.UpdateOne").Msg("databaseRepository")
		if mongo.IsDuplicateKeyError(err) {
			return common.NewErrorResponse(http.StatusConflict, err, fmt.Sprintf("A database with the name `%s` is existed!", data.Name), "ErrDatabaseDuplicated")
		}
		return common.NewErrorResponse(http.StatusInternalServerError, err, "Cannot update database", "ErrCannotUpdateDatabase")
	}
	return nil
}
