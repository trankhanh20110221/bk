package repository

import (
	"context"
	"errors"
	"net/http"
	"time"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"training-doctor-manager/common"
	"training-doctor-manager/pkg/token/model"
)

type AuthTokenRepository interface {
	CreateToken(c context.Context, token model.AuthToken) (*model.AuthToken, error)
	GetTokenByTokenId(ctx context.Context, tokenId primitive.ObjectID) (*model.AuthToken, error)
	DeleteTokensByAccountId(ctx context.Context, accountID primitive.ObjectID) error
}

func NewAuthTokenRepository(db *mongo.Database) AuthTokenRepository {
	return &authTokenRepository{
		coll: db.Collection(model.CollectionAuthToken),
	}
}

type authTokenRepository struct {
	coll *mongo.Collection
}

func (repo *authTokenRepository) CreateToken(c context.Context, token model.AuthToken) (*model.AuthToken, error) {
	currentTime := time.Now()
	token.CreatedAt = currentTime
	token.UpdatedAt = currentTime
	result, err := repo.coll.InsertOne(c, token)
	if err != nil {
		logger.Error().Err(err).Str("function", "CreateToken").Str("functionInline", "rp.coll.InsertOne").Msg("authTokenRepository")
		return nil, common.NewErrorResponse(http.StatusBadRequest, err, "Cannot create Token", "ErrCannotCreateToken")
	}
	token.ID = result.InsertedID.(primitive.ObjectID)
	return &token, nil
}

func (repo *authTokenRepository) DeleteTokensByAccountId(ctx context.Context, accountID primitive.ObjectID) error {
	if _, err := repo.coll.DeleteMany(ctx, bson.D{{"account_id", accountID}}); err != nil {
		logger.Error().Err(err).Str("function", "DeleteTokensByAccountId").Str("functionInline", "rp.coll.DeleteMany").Msg("authTokenRepository")
		return common.NewErrorResponse(http.StatusInternalServerError, err, "Cannot delete token", "ErrCannotDeleteToken")
	}
	return nil
}

func (repo *authTokenRepository) GetTokenByTokenId(ctx context.Context, tokenId primitive.ObjectID) (*model.AuthToken, error) {
	var data *model.AuthToken
	if err := repo.coll.FindOne(ctx, bson.M{"_id": tokenId}).Decode(&data); errors.Is(err, mongo.ErrNoDocuments) {
		logger.Error().Err(err).Str("function", "GetTokenByTokenId").Str("functionInline", "rp.coll.FindOne").Msg("authTokenRepository")
		return nil, common.NewErrorResponse(http.StatusNotFound, err, "Token not found", "ErrTokenNotFound")
	}
	return data, nil
}
