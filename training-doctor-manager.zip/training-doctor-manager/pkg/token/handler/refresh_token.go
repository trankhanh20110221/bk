package tokenhandler

import (
	"net/http"

	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
	"training-doctor-manager/common"
	"training-doctor-manager/pkg/token/model"
)

func (hdl *authTokenHandler) RefreshToken() fiber.Handler {
	return func(c *fiber.Ctx) error {
		var dataRequest model.RefreshTokenRequest

		if err := c.BodyParser(&dataRequest); err != nil {
			return common.NewErrorResponse(http.StatusBadRequest, err, "Invalid request", "ErrInvalidRequest")
		}

		validate := validator.New()

		err := validate.Struct(dataRequest)
		if err != nil {
			errors := err.(validator.ValidationErrors)
			return common.NewErrorResponse(http.StatusBadRequest, errors, "Validation error", "ErrValidation")
		}

		dataResponse, err := hdl.tokenUC.RefreshToken(c.Context(), &dataRequest)
		if err != nil {
			return err
		}

		return common.SuccessResponse(c, http.StatusOK, dataResponse)
	}
}
