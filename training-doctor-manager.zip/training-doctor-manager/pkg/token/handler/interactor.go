package tokenhandler

import (
	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
	"training-doctor-manager/pkg/token/usecase"
)

type authTokenHandler struct {
	tokenUC   usecase.TokenUsecase
	validator *validator.Validate
}

func NewTokenHandler(tokenUsecase usecase.TokenUsecase, validator *validator.Validate) AuthTokenHandler {
	return &authTokenHandler{tokenUC: tokenUsecase, validator: validator}
}

type AuthTokenHandler interface {
	RefreshToken() fiber.Handler
}
