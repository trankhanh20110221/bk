package parameters

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
	"training-doctor-manager/common/request"
	"training-doctor-manager/pkg/models"
)

type DatabaseCreationRequest struct {
	Name           string `json:"name" validate:"required"`
	Description    string `json:"description" validate:"lte=255"`
	Uri            string `json:"uri" validate:"required,mongo_uri,no_space"`
	DBName         string `json:"db_name" validate:"required,no_space"`
	TestConnection bool   `json:"test_connection"`
}

type DatabaseCreationResponse struct {
	ID string `json:"id"`
}

type DatabaseUpdateBodyRequest struct {
	Name           string `json:"name" validate:"required"`
	Description    string `json:"description" validate:"lte=255"`
	Uri            string `json:"uri" validate:"required,mongo_uri,no_space"`
	DBName         string `json:"db_name" validate:"required,no_space"`
	TestConnection bool   `json:"test_connection,omitempty"`
}

type DatabaseUpdateParamRequest struct {
	ID primitive.ObjectID `params:"id"`
}

type DatabaseUpdateResponse struct {
	Status bool `json:"status"`
}

type DatabaseDeletionParamRequest struct {
	ID primitive.ObjectID `params:"id"`
}

type DatabaseDeletionResponse struct {
	Status bool `json:"status"`
}

type DatabaseManyDeletionRequest struct {
	IDs []primitive.ObjectID `json:"ids" validate:"required,min=1"`
}

type DatabaseGetOneRequest struct {
	ID primitive.ObjectID `params:"id"`
}

type DatabaseGetOneResponse struct {
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
	Name        string    `json:"name"`
	Description string    `json:"description"`
	Uri         string    `json:"uri"`
	DBName      string    `json:"db_name"`
}

type DatabaseGetAllRequest struct {
	Filter FilterDatabase
	Paging request.Paging
}

type DatabaseGetAllResponse struct {
	Paging  *request.Paging   `json:"paging"`
	Records []models.Database `json:"records"`
}

type FilterDatabase struct {
	Name string `query:"database_name"`
}
