package parameters

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

type SyncingResponse struct {
	CreatedAt      time.Time          `json:"created_at"`
	UpdatedAt      time.Time          `json:"updated_at"`
	CollectionName string             `json:"collection_name"`
	DatabaseName   string             `json:"database_name"`
	Error          string             `json:"error"`
	Type           int                `json:"type"`
	TotalTasks     int                `json:"total_tasks"`
	CompletedTasks int                `json:"completed_tasks"`
	ID             primitive.ObjectID `json:"_id,omitempty"`
	UserID         primitive.ObjectID `json:"user_id"`
	DatabaseID     primitive.ObjectID `json:"database_id"`
}

type SyncingGetAllResponse struct {
	Data []SyncingResponse `json:"records"`
}

type SyncingDeletionRequest struct {
	ID primitive.ObjectID `params:"id"`
}

type SyncingDeletionResponse struct {
	ID primitive.ObjectID `json:"id"`
}
