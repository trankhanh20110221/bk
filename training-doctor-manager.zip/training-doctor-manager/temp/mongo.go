package temp

import "go.mongodb.org/mongo-driver/bson"

func MergeConditions(original bson.M, additional bson.M) bson.M {
	for key, value := range additional {
		original[key] = value
	}
	return original
}
