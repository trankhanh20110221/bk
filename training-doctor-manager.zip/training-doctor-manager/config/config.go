package config

import (
	"crypto/rsa"
	"time"

	"github.com/caarlos0/env/v11"
	"github.com/golang-jwt/jwt/v5"
	"github.com/joho/godotenv"
	"github.com/rs/zerolog/log"
)

type Config struct {
	App   AppConfig
	Mongo MongoConfig
	Jwt   JwtConfig
}

type AppConfig struct {
	Port  string `env:"APP_PORT" envDefault:"8080"`
	Debug bool   `env:"DEBUG" envDefault:"true"`
}

type MongoConfig struct {
	Uri      string        `env:"MONGO_URI" envDefault:"mongodb://127.0.0.1:27017/"`
	Database string        `env:"MONGO_DB" envDefault:"drmanager"`
	Timeout  time.Duration `env:"MONGO_TIMEOUT" envDefault:"10s"`
}

type JwtConfig struct {
	VerifyKey          *rsa.PublicKey
	SignKey            *rsa.PrivateKey
	PrivateKey         string        `env:"PRIVATE_KEY,file" envDefault:"secret/doctor.rsa"`
	PublicKey          string        `env:"PUBLIC_KEY,file" envDefault:"secret/doctor.rsa.pub"`
	AccessTokenExpiry  time.Duration `env:"ACCESS_TOKEN_EXPIRY" envDefault:"15m"`
	RefreshTokenExpiry time.Duration `env:"REFRESH_TOKEN_EXPIRY" envDefault:"168h"`
}

var (
	config *Config
)

func InitKeys(c *Config) {
	var err error

	c.Jwt.SignKey, err = jwt.ParseRSAPrivateKeyFromPEM([]byte(c.Jwt.PrivateKey))
	if err != nil {
		log.Fatal().Err(err)
	}

	c.Jwt.VerifyKey, err = jwt.ParseRSAPublicKeyFromPEM([]byte(c.Jwt.PublicKey))
	if err != nil {
		log.Fatal().Err(err)
	}
}

func LoadConfig() *Config {
	var c Config

	_ = godotenv.Load()
	if err := env.Parse(&c); err != nil {
		log.Printf("%+v\n", err)
	}

	InitKeys(&c)
	return &c
}

func GetConfig() Config {
	if config == nil {
		_ = godotenv.Load()
		config = &Config{}
		if err := env.Parse(config); err != nil {
			log.Fatal().Err(err).Msg("Get Config Error")
		}
	}
	return *config
}
